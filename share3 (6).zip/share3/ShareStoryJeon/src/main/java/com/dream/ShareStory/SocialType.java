package com.dream.ShareStory;

public enum SocialType {
    KAKAO, NAVER, GOOGLE
}
