package com.dream.ShareStory.config;

import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.service.MemberService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
@RequiredArgsConstructor
public class GlobalControllerAdvice {

    private final MemberService memberService;
//네브바 전용 컨트롤러
    @ModelAttribute
    public void addLoginMemberToModel(HttpSession session, Model model) {
        Long loginId = (Long) session.getAttribute("id");

        if (loginId != null) {
            MemberDTO memberDTO = memberService.findbyId(loginId);
            model.addAttribute("member", memberDTO); // 모든 템플릿에서 사용 가능!
        }
    }
}
