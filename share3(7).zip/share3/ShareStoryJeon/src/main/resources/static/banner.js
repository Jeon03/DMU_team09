const slides = document.querySelectorAll('.slide');
let current = 0;

function showSlide(index) {
    document.querySelector('.slides').style.transform = `translateX(-${index * 100}%)`;
}

document.querySelector('.prev').addEventListener('click', () => {
    current = (current - 1 + slides.length) % slides.length;
    showSlide(current);
});

document.querySelector('.next').addEventListener('click', () => {
    current = (current + 1) % slides.length;
    showSlide(current);
});

// 자동 슬라이드
setInterval(() => {
    current = (current + 1) % slides.length;
    showSlide(current);
}, 5000);
