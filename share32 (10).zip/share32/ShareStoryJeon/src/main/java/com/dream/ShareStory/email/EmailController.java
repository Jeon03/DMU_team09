package com.dream.ShareStory.email;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class EmailController {

    private final EmailService emailService;

    public EmailController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping("/send-email")
    public ResponseEntity<String> sendEmail(@RequestBody EmailRequest request) {
        try {
            emailService.sendSimpleMail(request.getTo(), request.getSubject(), request.getText());
            return ResponseEntity.ok("이메일 전송 성공");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("이메일 전송 실패");
        }
    }
}
