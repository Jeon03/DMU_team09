package com.dream.ShareStory.controller;
import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.entity.MessageEntity;
import com.dream.ShareStory.dto.MessageDTO;
import com.dream.ShareStory.oldItem.oldItem;
import com.dream.ShareStory.oldItem.oldItemService;
import com.dream.ShareStory.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import com.dream.ShareStory.dto.MessageDTO;
import java.util.List;
import java.util.stream.Collectors;


@Controller
@RequiredArgsConstructor
@RequestMapping("/message")
public class MessageController {

    private final MessageService messageService;
    private final oldItemService oldItemService;

    // MessageEntity를 MessageDTO로 변환
    public MessageDTO convertToMessageDTO(MessageEntity messageEntity) {
        MessageDTO messageDTO = new MessageDTO();
        messageDTO.setSenderId(messageEntity.getSender().getId()); // senderId 설정
        messageDTO.setReceiverId(messageEntity.getReceiver().getId()); // receiverId 설정
        messageDTO.setTitle(messageEntity.getTitle());
        messageDTO.setContent(messageEntity.getContent());
        messageDTO.setItemId(messageEntity.getItemId());
        return messageDTO;
    }

    @PostMapping("/send")
    public ResponseEntity<String> sendMessage(@RequestBody MessageDTO messageDTO) {
        try {
            messageService.sendMessage(messageDTO);
            return ResponseEntity.ok("쪽지를 보냈습니다!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("쪽지 전송 실패: " + e.getMessage());
        }
    }

    @GetMapping("/detail/{id}")
    public String showMessageDetail(@PathVariable Long id, @SessionAttribute(name = "memberId", required = false) String memberId, Model model) {
        if (memberId == null) {
            return "redirect:/login"; // 로그인하지 않았다면 로그인 페이지로 리다이렉트
        }

        MessageEntity message = messageService.getMessageById(id);
        if (message == null || !message.getReceiver().getId().equals(memberId)) {
            return "redirect:/message/inbox"; // 본인의 쪽지가 아니면 쪽지함으로 리다이렉트
        }

        model.addAttribute("message", message);
        return "messageDetail"; // 쪽지 상세 페이지로 리턴
    }
    @GetMapping("/inbox")
    public String showInbox(@SessionAttribute(name = "id", required = false) Long memberId, Model model) {
        if (memberId == null) {
            return "redirect:/login";
        }
        List<oldItem> items = oldItemService.getItemsForUser(memberId);
         model.addAttribute("items", items);
        List<MessageDTO> message = messageService.getMessagesForUser(memberId);
        model.addAttribute("message", message);
        return "inbox";
    }



}
