package com.dream.ShareStory.PAY;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId;
    private String impUid;
    private String merchantUid;
    private Integer amount;
    private String status; // paid, failed 등
    private LocalDateTime paidAt;
}
