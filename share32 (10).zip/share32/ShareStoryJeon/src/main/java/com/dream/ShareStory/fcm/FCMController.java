package com.dream.ShareStory.fcm;

import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.repository.MemberRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
public class FCMController {

    private final FCMUtil fcmUtil;
    private final MemberRepository memberRepository;
    private final FcmTokenRepository fcmTokenRepository;

    private String latestToken; // 임시 저장용 (테스트 용도)

    // 생성자에 모든 의존성 주입
    public FCMController(FCMUtil fcmUtil,
                         MemberRepository memberRepository,
                         FcmTokenRepository fcmTokenRepository) {
        this.fcmUtil = fcmUtil;
        this.memberRepository = memberRepository;
        this.fcmTokenRepository = fcmTokenRepository;
    }

    // 프론트에서 받은 토큰을 임시 저장 (테스트 용도)
    @PostMapping("/fcm-token")
    public ResponseEntity<Void> receiveToken(@RequestBody Map<String, String> body) {
        latestToken = body.get("token");
        return ResponseEntity.ok().build();
    }

    // 저장된 토큰으로 푸시 전송
    @PostMapping("/send-push")
    public ResponseEntity<String> send() {
        try {
            fcmUtil.send(latestToken, "웹 알림!", "Spring 서버에서 전송됨");
            return ResponseEntity.ok("전송 완료");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("실패: " + e.getMessage());
        }
    }

    // 실제 DB 저장용
   /* @PostMapping("/fcm/save-token")
    public ResponseEntity<?> saveFcmToken(@RequestBody Map<String, String> payload,
                                          HttpSession session) {
        String token = payload.get("token");
        Long memberId = (Long) session.getAttribute("memberId"); // 세션에서 로그인 ID 꺼냄

        if (memberId != null && token != null) {
            MemberEntity member = memberRepository.findById(memberId).orElse(null);
            if (member != null) {
                // 중복 체크
                boolean tokenExists = fcmTokenRepository.findByToken(token).isPresent();
                if (!tokenExists) {
                    FcmToken fcmToken = new FcmToken();
                    fcmToken.setToken(token);
                    fcmToken.setMember(member);
                    fcmTokenRepository.save(fcmToken);
                }
                return ResponseEntity.ok("Saved");
            }
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Missing data");
    }*/
    @PostMapping("/fcm/save-token")
    public ResponseEntity<?> saveFcmToken(@RequestBody Map<String, String> payload,
                                          HttpSession session) {
        Long memberId = (Long) session.getAttribute("sessionMemberId"); // 세션에서 memberId 가져오기
        if (memberId == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("로그인된 사용자가 아닙니다.");
        }

        String token = payload.get("token");
        if (token == null || token.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("토큰이 없습니다.");
        }

        MemberEntity member = memberRepository.findById(memberId).orElse(null);
        if (member != null) {
            FcmToken fcmToken = new FcmToken();
            fcmToken.setToken(token);
            fcmToken.setMember(member);
            fcmTokenRepository.save(fcmToken);
            return ResponseEntity.ok("Saved");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("사용자를 찾을 수 없습니다.");
    }

    @PostMapping("/send-push-notification")
    public ResponseEntity<?> sendPushNotification(@RequestBody PushNotificationRequest request) {
        try {
            // 푸시 알림 전송
            fcmUtil.send(request.getToken(), request.getTitle(), request.getBody());
            return ResponseEntity.ok().body(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", e.getMessage()));
        }

    }
    @GetMapping("/fcm/get-tokens/{receiverId}")
    public ResponseEntity<?> getTokens(@PathVariable Long receiverId) {
        List<FcmToken> tokens = fcmTokenRepository.findByMember_Id(receiverId);
        List<String> tokenValues = tokens.stream().map(FcmToken::getToken).toList();
        return ResponseEntity.ok(tokenValues);
    }

}
