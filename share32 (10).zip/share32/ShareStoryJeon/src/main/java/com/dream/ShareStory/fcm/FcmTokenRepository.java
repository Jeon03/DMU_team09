package com.dream.ShareStory.fcm;

import com.dream.ShareStory.entity.MemberEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FcmTokenRepository extends JpaRepository<FcmToken, Long> {

    // 특정 사용자에 해당하는 토큰 전체 조회
    List<FcmToken> findByMember(MemberEntity member);

    // 중복 저장 방지를 위한 토큰 존재 여부 확인
    Optional<FcmToken> findByToken(String token);

    // 필요 시, 사용자 ID로 삭제도 가능
    void deleteByMember(MemberEntity member);
    List<FcmToken> findByMember_Id(Long memberId);
}
