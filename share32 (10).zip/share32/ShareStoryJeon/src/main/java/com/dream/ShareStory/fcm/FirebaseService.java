package com.dream.ShareStory.fcm;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FirebaseService {


    private final FcmTokenRepository fcmTokenRepository;
    private final FCMUtil fcmUtil;
    public void sendMessageTo(String targetToken, String title, String body) {
        Message message = Message.builder()
                .setToken(targetToken)
                .setNotification(Notification.builder()
                        .setTitle(title)
                        .setBody(body)
                        .build())
                .build();

        try {
            String response = FirebaseMessaging.getInstance().send(message);
            System.out.println("FCM 전송 성공: " + response);
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
        }
    }
    public void sendPushNotificationToReceiver(Long receiverId, String messageTitle, String messageBody) {
        List<FcmToken> receiverTokens = fcmTokenRepository.findByMember_Id(receiverId);
        if (!receiverTokens.isEmpty()) {
            for (FcmToken tokenEntity : receiverTokens) {
                String token = tokenEntity.getToken();
                try {
                    fcmUtil.send(token, messageTitle, messageBody); // 예외 처리
                } catch (Exception e) {
                    System.out.println("푸시 전송 실패: " + e.getMessage());
                    // 로그로 남기거나 실패 처리를 할 수 있음
                }
            }
        } else {
            System.out.println("상대방의 FCM 토큰이 없습니다.");
        }
    }


}
