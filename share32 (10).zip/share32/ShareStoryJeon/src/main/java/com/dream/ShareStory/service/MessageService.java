package com.dream.ShareStory.service;

import com.dream.ShareStory.dto.MessageDTO;
import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.entity.MessageEntity;
import com.dream.ShareStory.fcm.FcmToken;
import com.dream.ShareStory.fcm.FcmTokenRepository;
import com.dream.ShareStory.fcm.FirebaseService;
import com.dream.ShareStory.repository.MemberRepository;
import com.dream.ShareStory.repository.MessageRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MessageService {

    private final MemberRepository memberRepository;
    private final MessageRepository messageRepository;

    private final FcmTokenRepository fcmTokenRepository;
    private final FirebaseService firebaseService;

    public MessageService(MemberRepository memberRepository,
                          MessageRepository messageRepository,
                          FcmTokenRepository fcmTokenRepository,
                          FirebaseService firebaseService) {
        this.memberRepository = memberRepository;
        this.messageRepository = messageRepository;
        this.fcmTokenRepository = fcmTokenRepository;
        this.firebaseService = firebaseService;
    }

    public void sendMessage(MessageDTO dto) {
        MemberEntity sender = memberRepository.findById(dto.getSenderId())
                .orElseThrow(() -> new IllegalArgumentException("보낸 사람 없음"));
        MemberEntity receiver = memberRepository.findById(dto.getReceiverId())
                .orElseThrow(() -> new IllegalArgumentException("받는 사람 없음"));

        MessageEntity message = new MessageEntity();
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setTitle(dto.getTitle());
        message.setContent(dto.getContent());
        message.setSentAt(LocalDateTime.now());

        messageRepository.save(message);
    }
    public MessageEntity getMessageById(Long id) {
        Optional<MessageEntity> message = messageRepository.findById(id);
        return message.orElse(null); // 없으면 null 리턴
    }
    public List<MessageDTO> getMessagesForUser(Long receiverId) {
        List<MessageEntity> message = messageRepository.findByReceiverId(receiverId);

        return message.stream().map(entity -> {
            MessageDTO dto = new MessageDTO();
            dto.setId(entity.getId());
            dto.setSenderId(entity.getSender().getId());
            dto.setSenderName(entity.getSender().getName()); // 이름 설정 중요
            dto.setReceiverId(entity.getReceiver().getId());
            dto.setTitle(entity.getTitle());
            dto.setContent(entity.getContent());
            dto.setSentAt(entity.getSentAt());

            return dto;
        }).toList();
    }

    public void sendMessageAndNotify(MessageDTO dto) {
        // 1. 보낸 사람과 받는 사람 조회
        MemberEntity sender = memberRepository.findById(dto.getSenderId())
                .orElseThrow(() -> new IllegalArgumentException("보낸 사람 없음"));
        MemberEntity receiver = memberRepository.findById(dto.getReceiverId())
                .orElseThrow(() -> new IllegalArgumentException("받는 사람 없음"));

        // 2. 메시지 생성 및 저장
        MessageEntity message = MessageEntity.fromDto(dto, sender, receiver);
        messageRepository.save(message);

        // 3. FCM 토큰 조회
        List<FcmToken> tokenList = fcmTokenRepository.findByMember_Id(dto.getReceiverId());

        // 4. FCM 전송
        for (FcmToken token : tokenList) {
            firebaseService.sendMessageTo(
                    token.getToken(),
                    "새 쪽지 도착",
                    dto.getTitle()
            );
        }
    }

}
