package com.dream.ShareStory.fcm;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.FileInputStream;
import java.io.InputStream;

import org.springframework.core.io.ClassPathResource;
@Component
public class FCMUtil {

    @PostConstruct
    public void init() throws Exception {
        ClassPathResource resource = new ClassPathResource("firebase/dreamfire-be9b9-firebase-adminsdk-fbsvc-8035fa3aa9.json");
        try (InputStream in = resource.getInputStream()) {
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(in))
                    .build();
            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }
        }
    }

    public void send(String token, String title, String body) throws Exception {
        Message message = Message.builder()
                .setToken(token)
                .setNotification(Notification.builder()
                        .setTitle(title)
                        .setBody(body)
                        .build())
                .build();

        try {
            FirebaseMessaging.getInstance().send(message);
        } catch (FirebaseMessagingException e) {
            System.out.println("FCM 전송 실패: " + e.getErrorCode()); // 예: registration-token-not-registered
            if ("registration-token-not-registered".equals(e.getErrorCode())) {
                // 이 경우 DB에서 토큰 삭제 유도 가능
                throw new Exception("해당 토큰은 더 이상 유효하지 않습니다.");
            } else {
                throw new Exception("푸시 알림 전송 중 오류가 발생했습니다: " + e.getMessage());
            }
        }
    }
}
