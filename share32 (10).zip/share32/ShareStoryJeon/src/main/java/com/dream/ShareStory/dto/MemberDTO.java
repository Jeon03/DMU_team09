package com.dream.ShareStory.dto;


import com.dream.ShareStory.entity.MemberEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor  //기본생성자 자동생성
@ToString
public class MemberDTO {
    private Long id;
    private String email;
    private String password;
    private String name;
    private Integer  age;
    private String city;
    private Integer points;
    private Double latitude;
    private Double longitude;

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public MemberDTO(Long id, String name, String email, Integer age, String city, String password, Integer points) {



    this.id = id;
    this.name = name;
    this.email = email;
    this.age = age;
    this.city = city;
    this.password = password;
    this.points = points;
        }

    public static MemberDTO toMemberDTO(MemberEntity memberEntity){
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setId(memberEntity.getId());
        memberDTO.setEmail(memberEntity.getEmail());
        memberDTO.setPassword(memberEntity.getPassword());
        memberDTO.setName(memberEntity.getName());
        memberDTO.setAge(memberEntity.getAge());
        memberDTO.setCity(memberEntity.getCity());
        memberDTO.setPoints(memberEntity.getPoints());
        memberDTO.setLatitude(memberEntity.getLatitude());
        memberDTO.setLongitude(memberEntity.getLongitude());// DTO에 엔티티의 points 값을 넣는 게 맞음
//0402추가
        return memberDTO;
    }
}
