package com.dream.ShareStory.service;

import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.lotate.Location;
import com.dream.ShareStory.lotate.LocationService;
import com.dream.ShareStory.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    private final LocationService locationService;

    // 회원가입 메서드
    public MemberEntity signup(MemberDTO dto) {
        // 사용자가 입력한 도시로 위도/경도 조회
        Location location = locationService.getCoordinates(dto.getCity());
        if (location != null) {
            // 위도와 경도를 DTO에 설정
            dto.setLatitude(location.getLatitude());
            dto.setLongitude(location.getLongitude());
        } else {
            // 위도/경도 조회 실패 시 처리 방법 추가 (예: 기본값 설정 또는 예외 처리)
            dto.setLatitude(0.0);
            dto.setLongitude(0.0);
        }

        // DTO를 엔티티로 변환
        MemberEntity member = MemberEntity.toMemberEntity(dto);

        // DB 저장
        return memberRepository.save(member);
    }

    public MemberDTO login(MemberDTO memberDTO) {
        Optional<MemberEntity> byMemberEmail = memberRepository.findByEmail(memberDTO.getEmail());
        if (byMemberEmail.isPresent()) {
            MemberEntity memberEntity = byMemberEmail.get();
            if (memberEntity.getPassword().equals(memberDTO.getPassword())) {
                MemberDTO dto = MemberDTO.toMemberDTO(memberEntity);
                return dto;
            }
        }
        return null;
    }

    public List<MemberDTO> findAll() {
        List<MemberEntity> memberEntityList = memberRepository.findAll();
        List<MemberDTO> memberDTOList = new ArrayList<>();
        for (MemberEntity memberEntity : memberEntityList) {
            memberDTOList.add(MemberDTO.toMemberDTO(memberEntity));
        }
        return memberDTOList;
    }

    public MemberDTO findbyId(Long id) {
        Optional<MemberEntity> optionalMemberEntity = memberRepository.findById(id);
        return optionalMemberEntity.map(MemberDTO::toMemberDTO).orElse(null);
    }

    public MemberDTO updateForm(String email) {
        Optional<MemberEntity> optionalMemberEntity = memberRepository.findByEmail(email);
        return optionalMemberEntity.map(MemberDTO::toMemberDTO).orElse(null);
    }

    public void update(MemberDTO memberDTO) {
        // 1) DB에서 기존 엔티티 조회
        MemberEntity entity = memberRepository.findById(memberDTO.getId())
                .orElseThrow(() -> new RuntimeException("회원 정보를 찾을 수 없습니다."));

        // 2) 수정된 필드만 반영
        if (memberDTO.getPassword() != null && !memberDTO.getPassword().isEmpty()) {
            entity.setPassword(memberDTO.getPassword());
        }
        if (memberDTO.getAge() != null && memberDTO.getAge() > 0) {
            entity.setAge(memberDTO.getAge());
        }

        // 3) 도시가 바뀌었으면 좌표도 갱신
        String newCity = memberDTO.getCity();
        if (newCity != null && !newCity.isEmpty() && !newCity.equals(entity.getCity())) {
            entity.setCity(newCity);

            // ── 이 부분에 getCoordinates() 분기를 넣습니다 ──
            Location loc = locationService.getCoordinates(newCity);
            if (loc != null) {
                entity.setLatitude(loc.getLatitude());
                entity.setLongitude(loc.getLongitude());
            }
            // ────────────────────────────────────────────────
        }

        // 4) 변경된 엔티티 저장
        memberRepository.save(entity);
    }
    public void deleteById(Long id) {
        memberRepository.deleteById(id);
    }

    public MemberDTO updateForm(Long id) {
        MemberEntity memberEntity = memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("회원 정보를 찾을 수 없습니다."));
        return new MemberDTO(
                memberEntity.getId(),
                memberEntity.getName(),
                memberEntity.getEmail(),
                memberEntity.getAge(),
                memberEntity.getCity(),
                memberEntity.getPassword(),
                memberEntity.getPoints()
        );
    }

    public List<MemberDTO> findAllDTO() {
        List<MemberEntity> memberEntityList = memberRepository.findAll();
        List<MemberDTO> memberDTOList = new ArrayList<>();
        for (MemberEntity memberEntity : memberEntityList) {
            memberDTOList.add(MemberDTO.toMemberDTO(memberEntity));
        }
        return memberDTOList;
    }
}
