package com.dream.ShareStory.fcm;


import com.dream.ShareStory.entity.MemberEntity;
import jakarta.persistence.*;


import java.time.LocalDateTime;

@Entity
public class FcmToken {

    @Id
    @GeneratedValue
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public MemberEntity getMember() {
        return member;
    }

    public void setMember(MemberEntity member) {
        this.member = member;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    private String token;

    @ManyToOne
    @JoinColumn(name = "member_id", referencedColumnName = "id")
    private MemberEntity member;

    private LocalDateTime createdAt = LocalDateTime.now();

    // getter/setter 추가 가능
}
