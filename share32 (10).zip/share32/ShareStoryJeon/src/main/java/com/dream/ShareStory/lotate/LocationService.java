package com.dream.ShareStory.lotate;

import com.fasterxml.jackson.databind.JsonNode;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.springframework.web.util.UriUtils;

@Service
public class LocationService {

    @Value("${kakao.api.key}")
    private String apiKey;
    private final String KAKAO_API_KEY = "KakaoAK a01d968350b64daf6acc157111d296c8"; // ✅ 중괄호 제거

    private final RestTemplate restTemplate;

    public LocationService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // ① 주소 → 단일 Location 객체 반환
    // LocationService.java
    public Location getCoordinates(String address) {
        try {
            String encoded = UriUtils.encode(address, StandardCharsets.UTF_8);
            String url = "https://dapi.kakao.com/v2/local/search/address.json?query=" + encoded;

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "KakaoAK " + apiKey);
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<JsonNode> resp = restTemplate.exchange(
                    url, HttpMethod.GET, entity, JsonNode.class);

            JsonNode docs = resp.getBody().path("documents");
            if (docs.isArray() && docs.size() > 0) {
                JsonNode first = docs.get(0);
                String addrName  = first.path("address_name").asText("");
                String placeName = first.path("place_name").asText("");
                double lat = first.path("y").asDouble(0.0);
                double lng = first.path("x").asDouble(0.0);
                return new Location(addrName, placeName, lat, lng);
            }
            // 빈 결과일 때: 예외 대신 null 반환
            return null;

        } catch (Exception e) {
            // 예외 로깅 후 null 반환
            e.printStackTrace();
            return null;
        }
    }

    // ② 주소 → 여러 Location 리스트 반환
    public List<Location> searchAddress(String address) {
        try {
            String encodedAddress = UriUtils.encode(address, StandardCharsets.UTF_8);

            String url = "https://dapi.kakao.com/v2/local/search/address.json?query=" + encodedAddress;

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "KakaoAK a01d968350b64daf6acc157111d296c8");
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<JsonNode> response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);

            System.out.println("카카오 주소 검색 요청: " + url);
            System.out.println("카카오 응답: " + response.getBody());

            List<Location> result = new ArrayList<>();
            JsonNode documents = response.getBody().path("documents");

            for (JsonNode doc : documents) {
                String addrName = doc.get("address_name").asText();
                String placeName = doc.get("place_name").asText();
                double lat = doc.get("y").asDouble();
                double lng = doc.get("x").asDouble();
                result.add(new Location(placeName,addrName, lat, lng));
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException("주소 검색 실패", e);
        }
    }


    public boolean isKeywordMode(String query) {
        // 영문·한글 문자가 하나라도 있으면 true
        return query.chars().anyMatch(ch ->
                (ch >= '0' && ch <= '9') == false   // 숫자가 아닌 문자
                        && !Character.isWhitespace(ch)      // 공백도 제외
        );
    }
    public List<Location> searchKeyword(String query) {
        // 1) “시·도·구” + “동·로·길” + 숫자 패턴이 있으면 address.json, 아니면 keyword.json
        String baseUrl = isAddressQuery(query)
                ? "https://dapi.kakao.com/v2/local/search/address.json"
                : "https://dapi.kakao.com/v2/local/search/keyword.json";
        String url = baseUrl
                + "?query=" + URLEncoder.encode(query, StandardCharsets.UTF_8);

        System.out.println("[LocationService] 호출 URL ▶ " + url);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "KakaoAK a01d968350b64daf6acc157111d296c8");
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<String> resp = restTemplate.exchange(
                url, HttpMethod.GET, entity, String.class
        );
        System.out.println("[LocationService] 응답 ▶ " + resp.getBody());

        // 2) JSON 파싱
        List<Location> list = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(resp.getBody());
            JSONArray docs = root.getJSONArray("documents");
            for (int i = 0; i < docs.length(); i++) {
                JSONObject d = docs.getJSONObject(i);
                String addr  = d.optString("address_name", "");
                String place = d.optString("place_name", "");
                double lat   = d.optDouble("y",  0.0);
                double lng   = d.optDouble("x",  0.0);
                list.add(new Location(addr, place, lat, lng));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * “서울 양천구 목동 916” 처럼
     * – (시|도|군|구) + .+ (동|로|길) + [0-9] 패턴을 가지면 주소 모드
     */
    private boolean isAddressQuery(String q) {
        String regex = ".*[가-힣]+(시|도|군|구).*(동|로|길).*\\d+.*";
        return Pattern.compile(regex).matcher(q.trim()).matches();
    }



    public String getRegionFromCoordinates(double x, double y) {
        String url = "https://dapi.kakao.com/v2/local/geo/coord2regioncode.json?x=" + x + "&y=" + y;

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", KAKAO_API_KEY);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            JSONObject json = new JSONObject(response.getBody());
            String addressName = json.getJSONArray("documents").getJSONObject(0).getString("address_name");
            return addressName;
        } else {
            return "API 요청 실패";
        }
    }
    public String getCoordinatesFromAddress(String address) {
        String url = "https://dapi.kakao.com/v2/local/search/address.json?query=" + UriUtils.encode(address, StandardCharsets.UTF_8);

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", KAKAO_API_KEY);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            JSONObject json = new JSONObject(response.getBody());
            JSONObject document = json.getJSONArray("documents").getJSONObject(0);
            String x = document.getString("x");
            String y = document.getString("y");
            return "주소: " + address + "\nX(경도): " + x + "\nY(위도): " + y;
        } else {
            return "주소 좌표 변환 실패";
        }
    }

}
