package com.dream.ShareStory.PAY;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PayController

 {
     @GetMapping("/charge")
     public String payPage() {
         return "pay2.html";  // payment.html 파일을 반환
     }


 }
