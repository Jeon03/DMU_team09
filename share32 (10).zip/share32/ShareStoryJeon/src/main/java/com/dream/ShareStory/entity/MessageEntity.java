package com.dream.ShareStory.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "message")
public class MessageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 쪽지 ID

    @ManyToOne
    @JoinColumn(name = "sender_id", nullable = false)
    private MemberEntity sender; // 보낸 사람

    @ManyToOne
    @JoinColumn(name = "receiver_id", nullable = false)
    private MemberEntity receiver; // 받는 사람

    @Column(nullable = false)
    private String title; // 쪽지 제목

    @Column(nullable = false, length = 1000)
    private String content; // 쪽지 내용

    @Column(nullable = false)
    private LocalDateTime sentAt = LocalDateTime.now(); // 보낸 시간


    @Column(nullable = true) // itemId는 필수는 아닌 것으로 설정
    private Long itemId; // 아이템 ID 추가
    public static MessageEntity fromDto(com.dream.ShareStory.dto.MessageDTO dto, MemberEntity sender, MemberEntity receiver) {
        MessageEntity message = new MessageEntity();
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setTitle(dto.getTitle());
        message.setContent(dto.getContent());
        message.setSentAt(LocalDateTime.now()); // 현재 시간 저장

        // itemId가 있을 경우만 설정
        if (dto.getItemId() != null) {
            message.setItemId(dto.getItemId());
        }

        return message;
    }

}
