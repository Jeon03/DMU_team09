package com.dream.ShareStory.lotate;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/location")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    // ① 도로명 주소 → 단일 좌표
    @GetMapping("/coord")
    public ResponseEntity<Location> getCoordinates(@RequestParam("address") String address) {
        Location location = locationService.getCoordinates(address);
        if (location != null) {
            return ResponseEntity.ok(location);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }


    // 카카오 API를 통해 주소에서 좌표를 가져오는 함수
    public Map<String, Double> getCoords(String address) throws IOException {
        String apiUrl = "https://dapi.kakao.com/v2/local/search/address.json?query=" + URLEncoder.encode(address, "UTF-8");

        HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "KakaoAK a01d968350b64daf6acc157111d296c8");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String response = in.lines().collect(Collectors.joining());
        in.close();

        JSONObject json = new JSONObject(response);
        JSONArray documents = json.getJSONArray("documents");
        if (documents.length() == 0) {
            System.out.println("검색 결과 없음: " + address);
            return Collections.emptyMap();
        }

        JSONObject first = documents.getJSONObject(0);
        JSONObject roadAddr = first.optJSONObject("road_address"); // null일 수 있음
        if (roadAddr == null) {
            System.out.println("도로명 주소 없음 (지번만 있음): " + address);
            return Collections.emptyMap();
        }

        double lat = roadAddr.getDouble("y");
        double lng = roadAddr.getDouble("x");

        Map<String, Double> result = new HashMap<>();
        result.put("latitude", lat);
        result.put("longitude", lng);
        return result;
    }


    // ② 키워드 → 장소 리스트
    @GetMapping("/search")
    public List<Location> search(@RequestParam("query") String query) {
        System.out.println("[LocationController.search] 호출됨, query=" + query);
        return locationService.searchKeyword(query);
    }

    // ③ 특정 좌표로 해당 지역 정보 가져오기
    @GetMapping("/region")
    public String getRegion(@RequestParam double x, @RequestParam double y) {
        return locationService.getRegionFromCoordinates(x, y);
    }

    // ④ 주소에서 좌표 정보 가져오기 (카카오 API 사용)
    @GetMapping("/coord-string")
    public String getCoordFromAddress(@RequestParam String address) {
        return locationService.getCoordinatesFromAddress(address);
    }
}
