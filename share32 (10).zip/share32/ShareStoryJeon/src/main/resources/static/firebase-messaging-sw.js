importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-messaging-compat.js');

firebase.initializeApp({
    apiKey: "AIzaSyCuVuuFUoVRQ_jyLUSNUKAvLFzyIOC9BQ8",
    authDomain: "dreamfire-be9b9.firebaseapp.com",
    projectId: "dreamfire-be9b9",
    messagingSenderId: "805827793369",
    appId: "1:805827793369:web:d79a45e7d84502702889c8"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
    self.registration.showNotification(payload.notification.title, {
        body: payload.notification.body,
        icon: '/icon.png'
    });
});
