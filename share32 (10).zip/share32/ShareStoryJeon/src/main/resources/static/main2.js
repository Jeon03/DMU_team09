// 1) 아임포트 초기화 (본인 가맹점 식별코드로 변경)
IMP.init("imp11340050");

// 2) 버튼 클릭 이벤트 연결
document.getElementById("kg-charge-btn1")
    .addEventListener("click", KGpay_1000);

document.getElementById("kg-charge-btn5")
    .addEventListener("click", KGpay_5000);

document.getElementById("kg-charge-btn10")
    .addEventListener("click", KGpay_10000);
document.getElementById("kg-charge-btn50")
    .addEventListener("click", KGpay_50000);
// 3) KG이니시스(충전) 호출 함수
function KGpay_50000() {
    IMP.request_pay({
        pg           : "html5_inicis.INIpayTest",  // 테스트용 MID, 실서비스 MID로 변경
        pay_method   : "card",
        merchant_uid : "charge_" + new Date().getTime(),
        name         : "포인트 충전",
        amount       : 50000,                       // 충전할 금액
        buyer_email  : "user@example.com",
        buyer_name   : "홍길동",
        buyer_tel    : "010-1234-5678",
        m_redirect_url: "https://yourdomain.com/charge/complete" // 모바일 리디렉션 URL
    }, function (rsp) {
        if (rsp.success) {
            fetch("/user/chargePoints", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    amount: 50000
                })
            })
                .then(res => res.text())
                .then(data => {
                    alert(data);
                })
                .catch(err => {
                    console.error("충전 요청 실패:", err);
                    alert("서버에 충전 요청 중 문제가 발생했습니다.");
                });
        } else {
            alert("충전에 실패했습니다: " + rsp.error_msg);
        }
    });
}


function KGpay_1000() {
    IMP.request_pay({
        pg           : "html5_inicis.INIpayTest",  // 테스트용 MID, 실서비스 MID로 변경
        pay_method   : "card",
        merchant_uid : "charge_" + new Date().getTime(),
        name         : "포인트 충전",
        amount       : 1000,                       // 충전할 금액
        buyer_email  : "user@example.com",
        buyer_name   : "홍길동",
        buyer_tel    : "010-1234-5678",
        m_redirect_url: "https://yourdomain.com/charge/complete" // 모바일 리디렉션 URL
    }, function (rsp) {
        if (rsp.success) {
            fetch("/user/chargePoints", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    amount: 1000
                })
            })
                .then(res => res.text())
                .then(data => {
                    alert(data);
                })
                .catch(err => {
                    console.error("충전 요청 실패:", err);
                    alert("서버에 충전 요청 중 문제가 발생했습니다.");
                });
        } else {
            alert("충전에 실패했습니다: " + rsp.error_msg);
        }
    });
}


function KGpay_5000() {
    IMP.request_pay({
        pg           : "html5_inicis.INIpayTest",  // 테스트용 MID, 실서비스 MID로 변경
        pay_method   : "card",
        merchant_uid : "charge_" + new Date().getTime(),
        name         : "포인트 충전",
        amount       : 5000,                       // 충전할 금액
        buyer_email  : "user@example.com",
        buyer_name   : "홍길동",
        buyer_tel    : "010-1234-5678",
        m_redirect_url: "https://yourdomain.com/charge/complete" // 모바일 리디렉션 URL
    }, function (rsp) {
        if (rsp.success) {
            fetch("/user/chargePoints", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    amount: 5000
                })
            })
                .then(res => res.text())
                .then(data => {
                    alert(data);
                })
                .catch(err => {
                    console.error("충전 요청 실패:", err);
                    alert("서버에 충전 요청 중 문제가 발생했습니다.");
                });
        } else {
            alert("충전에 실패했습니다: " + rsp.error_msg);
        }
    });
}


function KGpay_10000() {
    IMP.request_pay({
        pg           : "html5_inicis.INIpayTest",  // 테스트용 MID, 실서비스 MID로 변경
        pay_method   : "card",
        merchant_uid : "charge_" + new Date().getTime(),
        name         : "포인트 충전",
        amount       : 10000,                       // 충전할 금액
        buyer_email  : "user@example.com",
        buyer_name   : "홍길동",
        buyer_tel    : "010-1234-5678",
        m_redirect_url: "https://yourdomain.com/charge/complete" // 모바일 리디렉션 URL
    }, function (rsp) {
        if (rsp.success) {
            fetch("/user/chargePoints", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    amount: 10000
                })
            })
                .then(res => res.text())
                .then(data => {
                    alert(data);
                })
                .catch(err => {
                    console.error("충전 요청 실패:", err);
                    alert("서버에 충전 요청 중 문제가 발생했습니다.");
                });
        } else {
            alert("충전에 실패했습니다: " + rsp.error_msg);
        }
    });
}


// 4) 기존 카드 결제 호출 함수
