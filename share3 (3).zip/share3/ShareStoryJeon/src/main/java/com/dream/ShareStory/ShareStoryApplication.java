package com.dream.ShareStory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareStoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareStoryApplication.class, args);
	}

}
