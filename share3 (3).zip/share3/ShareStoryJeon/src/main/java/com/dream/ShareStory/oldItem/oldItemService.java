package com.dream.ShareStory.oldItem;

import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class oldItemService {

    private final oldItemRepository oldItemRepository;
    private final MemberRepository memberRepository;

    @Autowired
    public oldItemService(oldItemRepository oldItemRepository, MemberRepository memberRepository) {
        this.oldItemRepository = oldItemRepository;
        this.memberRepository = memberRepository;
    }

    public oldItem registerItem(Long id, oldItem newItem) {
        MemberEntity member = memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("해당 id의 회원을 찾을 수 없습니다: " + id));

        newItem.setMember(member);
        return oldItemRepository.save(newItem);
    }

    public oldItem save(oldItem item) {
        return oldItemRepository.save(item);
    }

    public List<oldItem> getRecentItems(int limit) {
        Pageable pageable = PageRequest.of(0, limit, Sort.by("itemId").descending());
        return oldItemRepository.findAllByOrderByItemIdDesc(pageable);
    }

    public Optional<oldItem> getItemById(Long id) {
        return oldItemRepository.findById(id);
    }

    public List<oldItem> getAllItems() {
        return oldItemRepository.findAll();
    }
}
