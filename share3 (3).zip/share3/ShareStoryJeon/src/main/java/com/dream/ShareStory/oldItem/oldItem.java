package com.dream.ShareStory.oldItem;

import jakarta.persistence.*;
import lombok.*;
import com.dream.ShareStory.entity.MemberEntity;
import java.math.BigDecimal;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class oldItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private MemberEntity member;

    @Lob
    @ToString.Exclude
    private byte[] itemPicture;

    private String itemName;
    private String itemDetail;
    private String itemCategory;
    private BigDecimal itemPrice;
    private Integer itemQuantity;

    private String itemCondition;
    private String deliveryTransaction;
}
