package com.dream.ShareStory.controller;

import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    private final MemberService memberService;

    @Autowired  // 생성자 기반 주입 (추천 방식)
    public HomeController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/")
    public String index(){
        return "index";
    }
    @GetMapping("/navbarNoLo")
    public String navbarNoLoOnly() {
        return "navbarNoLo";
    }

    @GetMapping("/navbar")
    public String navbarOnly() {
        return "navbar";
    }
    @GetMapping("/banner")
    public String bannerOnly() {
        return "banner";
    }


}
