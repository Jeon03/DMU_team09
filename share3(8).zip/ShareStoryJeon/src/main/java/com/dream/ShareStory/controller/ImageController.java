package com.dream.ShareStory.controller;

import com.dream.ShareStory.oldItem.oldItem;
import com.dream.ShareStory.oldItem.oldItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.dream.ShareStory.oldItem.oldItemService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/image")
public class ImageController {

    @Autowired
    private oldItemRepository oldItemRepository;

    @GetMapping("/{itemId}")
    public ResponseEntity<byte[]> getImage(@PathVariable Long itemId) {
        return oldItemRepository.findById(itemId)
                .map(item -> {
                    byte[] imageData = item.getItemPicture();

                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.IMAGE_JPEG); // 확장자 맞게 조정: JPEG, PNG 등
                    return new ResponseEntity<>(imageData, headers, HttpStatus.OK);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    @GetMapping("/image/member/{memberId}")
    public ResponseEntity<List<String>> getImagesByMember(@PathVariable Long memberId) {
        List<oldItem> items = oldItemRepository.findAllByMember_IdOrderByItemIdDesc(memberId);
        List<String> imageUrls = new ArrayList<>();

        for (oldItem item : items) {
            imageUrls.add("/image/" + item.getItemId()); // 이미지 요청 URL 구성
        }

        return ResponseEntity.ok(imageUrls);
    }


/*
    @DeleteMapping("/image/delete/{id}")
    public ResponseEntity<Map<String, String>> deleteImage(@PathVariable Long id) {
        Map<String, String> response = new HashMap<>();

        boolean isDeleted = oldItemService.deleteImageById(id);

        if (isDeleted) {
            response.put("success", "true");
        } else {
            response.put("success", "false");
        }

        return ResponseEntity.ok(response);
    }

 */




    @GetMapping("/all")
    public ResponseEntity<List<String>> getAllImages() {
        List<oldItem> items = oldItemRepository.findAllByOrderByItemIdDesc(Pageable.unpaged());
        List<String> imageUrls = new ArrayList<>();

        for (oldItem item : items) {
            imageUrls.add("/image/" + item.getItemId());
        }

        return ResponseEntity.ok(imageUrls);
    }


}
