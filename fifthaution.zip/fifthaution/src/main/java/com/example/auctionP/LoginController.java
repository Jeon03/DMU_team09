package com.example.auctionP;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ModelAndView login(@RequestParam String username, @RequestParam String password, HttpSession session) {
        User user = userService.authenticate(username, password);

        if (user != null) {
            // 세션에 사용자 정보 저장
            session.setAttribute("username", user.getUsername());
            session.setAttribute("nickname", user.getNickname());
            session.setAttribute("password", user.getPassword());
            session.setAttribute("point", user.getPoint());

            // ✅ 루트 경로("/")로 리디렉트
            return new ModelAndView("redirect:/");
        } else {
            return new ModelAndView("login.html", "error", "Invalid username or password");
        }
    }

}
