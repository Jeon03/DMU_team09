package com.example.auctionP;

import jakarta.persistence.*;

@Entity
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String nickname;  // 닉네임 추가

    @Column(nullable = true)
    private String adress;  // 닉네임 추가

    @Column(nullable = true)
    private String phone;  // 닉네임 추가
    @Column(nullable = true)
    private int point;  // 닉네임 추가

// 닉네임 추가

    
    public User() {}

    // 기존 생성자 수정 (nickname 포함)
    public User(String username, String password, String nickname,String adress,String phone,int point) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.adress="";
        this.phone="";
        this.point=0;
        
    }

    // Getter & Setter
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    public String getAdress() { return adress; }
    public void setAdress(String adress) { this.adress = adress; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public int getPoint() { return point; }
    public void setPoint(int point) { this.point = point; }
}
