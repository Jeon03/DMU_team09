package com.example.auctionP;

public @interface SpringBootApplication {
}
