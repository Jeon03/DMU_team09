package com.example.auctionP.chatjava;

import com.example.auctionP.HttpSessionHandshakeInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // 메시지 브로커 설정
        config.enableSimpleBroker("/topic"); // 클라이언트가 구독할 주소
        config.setApplicationDestinationPrefixes("/app"); // 클라이언트가 메시지를 보낼 주소
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // WebSocket 연결을 위한 엔드포인트
        registry.addEndpoint("/ws")  // WebSocket 연결 지점
                .addInterceptors(new HttpSessionHandshakeInterceptor()) // 인터셉터 추가
                .withSockJS();  // SockJS를 사용하여 WebSocket을 지원하지 않는 환경에서도 동작
    }
    
}
