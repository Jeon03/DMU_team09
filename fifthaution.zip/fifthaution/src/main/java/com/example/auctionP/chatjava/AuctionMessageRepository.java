package com.example.auctionP.chatjava;


import org.springframework.data.jpa.repository.JpaRepository;

public interface AuctionMessageRepository extends JpaRepository<AuctionMessage, Long> {
    // 추가적인 쿼리 메소드가 필요하면 여기 작성
}
