package com.example.auctionP;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegisterController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ModelAndView register(@RequestParam String username,
                                 @RequestParam String password,
                                 @RequestParam String nickname,
                                 @RequestParam String adress,
                                 @RequestParam String phone) { // 닉네임 추가
        try {
            userService.registerUser(username, password, nickname,adress,phone); // 닉네임 포함해서 전달
            return new ModelAndView("redirect:/login.html");
        } catch (RuntimeException e) {
            return new ModelAndView("register.httml", "error", e.getMessage());
        }
    }
}
