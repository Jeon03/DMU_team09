package com.example.auctionP;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private com.example.auctionP.UserRepository userRepository;

    // 포인트 충전 요청을 처리하는 엔드포인트
    @PostMapping("/chargePoints")
    public ResponseEntity<String> chargePoint(@RequestBody ChargeRequest chargeRequest, HttpSession session) {
        // 세션에서 저장된 사용자 아이디와 비밀번호 가져오기
        String sessionUsername = (String) session.getAttribute("username");
        String sessionPassword = (String) session.getAttribute("password");

        // 로그인 여부 확인
        if (sessionUsername == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("로그인이 필요합니다.");
        }

        // 비밀번호 확인
        if (sessionPassword == null || !sessionPassword.equals(chargeRequest.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("비밀번호가 일치하지 않습니다.");
        }

        // 유저 정보 조회
        Optional<User> userOptional = userRepository.findByUsername(sessionUsername);
        User user = userOptional.orElse(null);
        
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("사용자를 찾을 수 없습니다.");
        }

        // 충전할 금액 처리 (기존 포인트 + 충전 금액)
        int newPoint = user.getPoint() + chargeRequest.getAmount();

        // DB에서 포인트 업데이트
        user.setPoint(newPoint);
        userRepository.save(user);

        // 세션에서 사용자 정보 업데이트
        session.setAttribute("user", user);  // 세션에 최신 사용자 정보 저장

        return ResponseEntity.ok("포인트 충전 완료! 현재 포인트: " + newPoint);
    }
}
