package com.example.auctionP.myPage;

import com.example.auctionP.User;
import com.example.auctionP.UserRepository;
import com.example.auctionP.oldItem.oldItem;
import com.example.auctionP.oldItem.oldItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

import java.util.List;
import java.util.Optional;

@Controller
public class MyPageController {

    @Autowired
    private oldItemRepository oldItemRepo;

    @Autowired
    private UserRepository userRepo;

    @GetMapping("/myPage")
    public String showMyPage(HttpSession session, Model model) {
        // 세션에서 username 가져오기
        String username = (String) session.getAttribute("username");

        // username이 없으면 로그인 페이지로 리다이렉트
        if (username == null || username.trim().isEmpty()) {
            return "redirect:/login";
        }

        // username으로 유저 정보 조회
        Optional<User> optionalUser = userRepo.findByUsername(username);
        if (optionalUser.isEmpty()) {
            throw new IllegalArgumentException("해당 사용자를 찾을 수 없습니다.");
        }

        User user = optionalUser.get();

        // username으로 등록된 oldItem 조회
        List<oldItem> oldItems = oldItemRepo.findByUsername(username);

        // 모델에 데이터 추가
        model.addAttribute("username", user.getUsername());
        model.addAttribute("nickname", user.getNickname());
        model.addAttribute("adress", user.getAdress()); // 오타 수정: adress → address
        model.addAttribute("phone", user.getPhone());
        model.addAttribute("point", user.getPoint());
        model.addAttribute("oldItems", oldItems);

        return "myPage"; // myPage.mustache 랜더링
    }
}