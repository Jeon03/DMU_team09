package com.example.auctionP;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private UserRepository userRepository;

    // 로그인 처리
    public User authenticate(String username, String password) {
        // findByUsername으로 사용자 조회 (Optional로 반환됨)
        Optional<User> optionalUser = userRepository.findByUsername(username);
        
        // Optional에서 User 객체 꺼내기
        User user = optionalUser.orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

        // 비밀번호 확인
        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("비밀번호가 틀렸습니다.");
        }

        return user; // 인증 성공한 사용자 반환
    }
}
