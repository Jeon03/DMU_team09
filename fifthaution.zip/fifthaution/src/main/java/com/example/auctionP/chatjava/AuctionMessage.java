package com.example.auctionP.chatjava;


import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "auctionroom")
public class AuctionMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auctionId;

    private String userId;
    private String nickname;
    private String message;

    @Column(name = "timestamp", columnDefinition = "DATETIME DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime timestamp;

    // 기본 생성자
    public AuctionMessage() {}

    // 생성자
    public AuctionMessage(String userId, String nickname, String message) {
        this.userId = userId;
        this.nickname = nickname;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    // Getter & Setter
    public Long getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(Long auctionId) {
        this.auctionId = auctionId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
