package com.example.auctionP.oldItem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface oldItemRepository extends JpaRepository<oldItem, Long> {

    // 최신 5개 경매 아이템을 내림차순으로 가져오는 메서드
    List<oldItem> findTop5ByOrderByItemIdDesc();
}
