package com.example.auctionP.oldItem;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface oldItemRepository extends JpaRepository<oldItem, Long> {

    // 특정 사용자가 등록한 아이템 전체 가져오기
    List<oldItem> findByUsername(String username);

    // 특정 사용자가 등록한 아이템 페이징처리하여 가져오기 (최신순)
    List<oldItem> findAllByUsernameOrderByItemIdDesc(String username, Pageable pageable);

    // 전체 사용자 아이템 중 최신 아이템 N개 페이징 처리하여 가져오기
    List<oldItem> findAllByOrderByItemIdDesc(Pageable pageable);

}