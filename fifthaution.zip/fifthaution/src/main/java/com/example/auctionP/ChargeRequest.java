package com.example.auctionP;

public class ChargeRequest {
    private int amount;      // 충전할 금액
    private String password; // 사용자 비밀번호
    private String userId;   // 사용자 ID (세션에서 확인할 수 있도록)

    // Getters and Setters
    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
