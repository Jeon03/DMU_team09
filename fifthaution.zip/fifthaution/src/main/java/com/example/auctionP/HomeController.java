package com.example.auctionP;

import com.example.auctionP.oldItem.oldItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpSession;
import com.example.auctionP.oldItem.oldItemService;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private oldItemService oldItemService;

    @GetMapping("/")
    public String home(Model model, HttpSession session) {
        String username = (String) session.getAttribute("username");
        model.addAttribute("username", username != null ? username : "Guest");

        // 최근 5개 경매 아이템을 가져옴
        List<oldItem> recentItems = oldItemService.getRecentItems(5);

        // 최근 아이템들을 home.mustache로 전달
        model.addAttribute("recentItems", recentItems);

        return "home"; // home.mustache로 데이터를 전달
    }
}
