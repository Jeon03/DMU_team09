package com.example.auctionP.chatjava;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;
import java.util.Map;

@Controller
public class ChatController {

    @Autowired
    private AuctionMessageRepository auctionMessageRepository;

    @MessageMapping("/chat")  // 클라이언트가 "/app/chat"으로 메시지를 보내면 실행됨
    @SendTo("/topic/messages")  // 모든 구독자에게 메시지 전송
    public ChatMessage sendMessage(ChatMessage message, SimpMessageHeaderAccessor headerAccessor) {
        Map<String, Object> sessionAttributes = headerAccessor.getSessionAttributes();
        
        // 세션 값 확인 로그 추가
        System.out.println("세션 정보: " + sessionAttributes);

        // 세션에서 username과 nickname을 가져옴
        String username = (String) sessionAttributes.get("username");
        String nickname = (String) sessionAttributes.get("nickname");

        if (username == null || nickname == null) {
            System.out.println("🚨 세션에 username 또는 nickname이 없습니다!");
            throw new RuntimeException("로그인이 필요합니다.");
        }

        // 메시지에 username과 nickname 설정
        message.setUserId(username);  // message.setUserId(username)로 설정
        message.setNickname(nickname);  // message.setNickname(nickname)으로 설정
        message.setTimestamp(LocalDateTime.now());

        // 메시지 저장
        AuctionMessage auctionMessage = new AuctionMessage(username, nickname, message.getMessage());
        auctionMessageRepository.save(auctionMessage);

        return message;
    }
}
