package com.example.auctionP.chatjava;

import java.time.LocalDateTime;

public class ChatMessage {
    private String userId;
    private String nickname;
    private String message;
    private LocalDateTime timestamp;

    // 생성자, Getter & Setter
    public ChatMessage() {}

    public ChatMessage(String userId, String nickname, String message, LocalDateTime timestamp) {
        this.userId = userId;
        this.nickname = nickname;
        this.message = message;
        this.timestamp = timestamp;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
