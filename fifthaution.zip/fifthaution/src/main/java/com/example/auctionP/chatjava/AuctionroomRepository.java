package com.example.auctionP.chatjava;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AuctionroomRepository extends JpaRepository<AuctionMessage, Long> {
    // 추가적인 쿼리 메서드를 필요에 따라 정의할 수 있습니다.
}
