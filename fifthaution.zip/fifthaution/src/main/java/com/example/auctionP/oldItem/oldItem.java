package com.example.auctionP.oldItem;

import jakarta.persistence.*;
import java.util.Base64;

@Entity
@Table(name = "oldItem")
public class oldItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;

    @Column(nullable = false)
    private String username;  // 문자열로 저장

    @Column(nullable = false)
    private String startingPrice; // 문자열로 저장

    @Column(nullable = false)
    private String locate;

    @Lob
    @Column(nullable = true)
    private byte[] itemPicture;  // 원본 이미지 데이터를 저장

    @Column(nullable = true, length = 20)
    private String sellerPhone;

    @Column(nullable = true, length = 20)
    private String buyerPhone;

    public oldItem() {}

    public oldItem(String username, String startingPrice, String locate, byte[] itemPicture, String sellerPhone, String buyerPhone) {
        this.username = username;
        this.startingPrice = startingPrice;
        this.locate = locate;
        this.itemPicture = itemPicture;
        this.sellerPhone = sellerPhone;
        this.buyerPhone = buyerPhone;
    }

    // Getter & Setter
    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(String startingPrice) {
        this.startingPrice = startingPrice;
    }

    public String getLocate() {
        return locate;
    }

    public void setLocate(String locate) {
        this.locate = locate;
    }

    public byte[] getItemPicture() {
        return itemPicture;
    }

    public void setItemPicture(byte[] itemPicture) {
        this.itemPicture = itemPicture;
    }

    public String getSellerPhone() {
        return sellerPhone;
    }

    public void setSellerPhone(String sellerPhone) {
        this.sellerPhone = sellerPhone;
    }

    public String getBuyerPhone() {
        return buyerPhone;
    }

    public void setBuyerPhone(String buyerPhone) {
        this.buyerPhone = buyerPhone;
    }

    // Base64로 변환된 아이템 이미지 반환
    public String getItemPictureBase64() {
        if (this.itemPicture != null) {
            return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(this.itemPicture);  // Base64로 변환
        }
        return null;  // itemPicture가 null이면 null 반환
    }


    // Base64 문자열을 byte[]로 변환하여 itemPicture에 저장
    public void setItemPictureBase64(String base64Image) {
        if (base64Image != null && !base64Image.isEmpty()) {
            this.itemPicture = Base64.getDecoder().decode(base64Image);  // Base64 문자열을 byte[]로 변환
        }
    }
}
