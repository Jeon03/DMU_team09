package com.example.auctionP.oldItem;

import jakarta.persistence.*;
import java.util.Arrays;

@Entity
public class oldItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;

    private String username;
    private String startingPrice;
    private String locate;

    // 이미지 데이터 저장 필드
    @Lob
    private byte[] itemPicture;

    private String sellerPhone;
    private String buyerPhone;

    // Getter와 Setter
    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(String startingPrice) {
        this.startingPrice = startingPrice;
    }

    public String getLocate() {
        return locate;
    }

    public void setLocate(String locate) {
        this.locate = locate;
    }

    public byte[] getItemPicture() {
        return itemPicture;
    }

    public void setItemPicture(byte[] itemPicture) {
        this.itemPicture = itemPicture;
    }

    public String getSellerPhone() {
        return sellerPhone;
    }

    public void setSellerPhone(String sellerPhone) {
        this.sellerPhone = sellerPhone;
    }

    public String getBuyerPhone() {
        return buyerPhone;
    }

    public void setBuyerPhone(String buyerPhone) {
        this.buyerPhone = buyerPhone;
    }

    @Override
    public String toString() {
        return "oldItem{" +
                "itemId=" + itemId +
                ", username='" + username + '\'' +
                ", startingPrice='" + startingPrice + '\'' +
                ", locate='" + locate + '\'' +
                ", itemPicture=" + Arrays.toString(itemPicture) +
                ", sellerPhone='" + sellerPhone + '\'' +
                ", buyerPhone='" + buyerPhone + '\'' +
                '}';
    }
}