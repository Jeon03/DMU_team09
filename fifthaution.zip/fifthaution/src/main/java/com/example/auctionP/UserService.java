package com.example.auctionP;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // 사용자 등록
    public User registerUser(String username, String password, String nickname, String address, String phone) {
        Optional<User> existingUser = userRepository.findByUsername(username); // Optional 사용
        if (existingUser.isPresent()) {
            throw new RuntimeException("Username already exists");
        }

        User user = new User(username, password, nickname, address, phone, 0);
        return userRepository.save(user);
    }

    // 사용자 인증
    public User authenticate(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password)
            .orElseThrow(() -> new RuntimeException("사용자 또는 비밀번호가 잘못되었습니다."));
    }

    // 포인트 충전
    public void chargePoints(String username, String amount, String password, HttpSession session) {
        Optional<User> optionalUser = userRepository.findByUsername(username); // Optional 사용
        User user = optionalUser.orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다."));

        // 비밀번호 검증
        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("비밀번호가 틀렸습니다.");
        }

        // 금액 검증
        int chargeAmount;
        try {
            chargeAmount = Integer.parseInt(amount);  // 문자열을 정수로 변환
        } catch (NumberFormatException e) {
            throw new RuntimeException("금액은 숫자만 입력해야 합니다.");
        }

        if (chargeAmount <= 0) {
            throw new RuntimeException("충전 금액은 1원 이상이어야 합니다.");
        }

        // 세션에서 현재 포인트 가져오기 (없으면 기본값 0)
        Integer currentSessionPoints = (Integer) session.getAttribute("userPoint");
        if (currentSessionPoints == null) {
            currentSessionPoints = 0;  // 세션에 포인트가 없으면 기본값 0
        }

        // 세션에서 포인트 계산 후, DB 업데이트
        int newPoints = currentSessionPoints + chargeAmount;
        session.setAttribute("userPoint", newPoints);  // 세션에 새 포인트 저장

        // DB 업데이트
        user.setPoint(newPoints);
        userRepository.save(user);
    }
}
