package com.example.auctionP;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Map;

public class HttpSessionHandshakeInterceptor implements HandshakeInterceptor {

    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {
        // HttpSession을 가져오기
        HttpSession httpSession = ((ServletServerHttpRequest) request).getServletRequest().getSession();

        // 세션에서 userId와 nickname을 추출해서 WebSocket 세션에 설정
        if (httpSession != null) {
            String username = (String) httpSession.getAttribute("username");
            String nickname = (String) httpSession.getAttribute("nickname");

            if (username != null) {
                attributes.put("username", username);
            }
            if (nickname != null) {
                attributes.put("nickname", nickname);
            }
        }

        // 핸드셰이크를 계속 진행할지 여부를 결정. 여기서는 true로 설정.
        return true;
    }

    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Exception exception) {
        // 핸드셰이크 후 처리할 로직이 있으면 여기에 작성
    }
}
