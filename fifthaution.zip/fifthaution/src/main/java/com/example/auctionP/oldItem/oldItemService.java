package com.example.auctionP.oldItem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class oldItemService {

    @Autowired
    private oldItemRepository oldItemRepository;

    // 최근 5개 경매 아이템을 가져오는 메서드
    public List<oldItem> getRecentItems(int limit) {
        return oldItemRepository.findTop5ByOrderByItemIdDesc();  // 최신 아이템 5개를 내림차순으로 가져오기
    }

    // 아이템을 등록하는 메서드
    public void registerItem(String username, String startingPrice, String locate, byte[] itemPicture, String sellerPhone, String buyerPhone) {
        // 새로운 아이템 객체 생성
        oldItem item = new oldItem(username, startingPrice, locate, itemPicture, sellerPhone, buyerPhone);

        // 아이템을 데이터베이스에 저장
        oldItemRepository.save(item);
    }
}
