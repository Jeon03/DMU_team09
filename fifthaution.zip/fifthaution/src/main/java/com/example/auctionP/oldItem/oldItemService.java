package com.example.auctionP.oldItem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class oldItemService {

    private static final Logger logger = LoggerFactory.getLogger(oldItemService.class);
    private final oldItemRepository oldItemRepository;

    @Autowired
    public oldItemService(oldItemRepository oldItemRepository) {
        this.oldItemRepository = oldItemRepository;
    }

    public List<oldItem> getRecentItems(int limit) {
        if (limit < 1) limit = 5;

        Pageable pageable = PageRequest.of(0, limit);
        List<oldItem> items = oldItemRepository.findAllByOrderByItemIdDesc(pageable);

        logger.debug("Fetched Items Count: {}", items.size());
        items.forEach(item -> logger.debug("Item ID: {}", item.getItemId()));

        return items;
    }

    public void registerItem(String username, String startingPrice, String locate,
                             byte[] itemPicture, String sellerPhone, String buyerPhone) {

        if (!StringUtils.hasText(username) || !StringUtils.hasText(startingPrice)) {
            throw new IllegalArgumentException("username과 startingPrice는 필수 입력값입니다.");
        }

        oldItem item = new oldItem();
        item.setUsername(username);
        item.setStartingPrice(startingPrice);
        item.setLocate(locate);
        item.setItemPicture(itemPicture);
        item.setSellerPhone(sellerPhone);
        item.setBuyerPhone(buyerPhone);

        oldItemRepository.save(item);
    }

    public List<oldItem> getItemsByUsername(String username) {
        if (!StringUtils.hasText(username)) {
            throw new IllegalArgumentException("username은 필수 입력값입니다.");
        }
        return oldItemRepository.findByUsername(username);
    }

    public byte[] getItemPicture(Long itemId) {
        oldItem item = oldItemRepository.findById(itemId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 아이템 ID입니다."));

        if (item.getItemPicture() == null || item.getItemPicture().length == 0) {
            throw new IllegalStateException("아이템의 이미지가 설정되지 않았습니다.");
        }
        return item.getItemPicture();
    }

    public List<oldItem> getAllItems() {
        return oldItemRepository.findAll();
    }
}