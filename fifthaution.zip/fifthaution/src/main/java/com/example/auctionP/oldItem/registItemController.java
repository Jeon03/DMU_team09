package com.example.auctionP.oldItem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

@Controller
public class registItemController {

    private static final Logger logger = LoggerFactory.getLogger(registItemController.class);
    private final oldItemService oldItemService;
    private final HttpSession session;

    @Autowired
    public registItemController(oldItemService oldItemService, HttpSession session) {
        this.oldItemService = oldItemService;
        this.session = session;
    }

    @GetMapping("/registItem")
    public ModelAndView showRegistItemPage(@RequestParam(required = false) String message,
                                           @RequestParam(required = false) String error) {
        String username = (String) session.getAttribute("username");

        if (!isValidUsername(username)) {
            return new ModelAndView("redirect:/login");
        }

        List<oldItem> recentItems = oldItemService.getRecentItems(5);

        ModelAndView modelAndView = new ModelAndView("registItem");
        modelAndView.addObject("username", username);
        modelAndView.addObject("message", message);
        modelAndView.addObject("error", error);
        modelAndView.addObject("recentItems", recentItems);
        modelAndView.addObject("buyerPhone", "");

        return modelAndView;
    }

    @PostMapping("/createItem")
    public ModelAndView registerItem(@RequestParam String startingPrice,
                                     @RequestParam String locate,
                                     @RequestParam("itemPicture") MultipartFile file,
                                     @RequestParam String sellerPhone,
                                     @RequestParam(value = "buyerPhone", required = false) String buyerPhone,
                                     RedirectAttributes redirectAttributes) {
        String username = (String) session.getAttribute("username");

        if (!isValidUsername(username)) {
            return buildErrorModelAndView("로그인이 필요합니다.");
        }

        try {
            if (file.isEmpty()) {
                return buildErrorModelAndView("업로드된 파일이 비어 있습니다.");
            }

            String contentType = file.getContentType();
            if (!isImageContentType(contentType)) {
                return buildErrorModelAndView("이미지 형식만 업로드할 수 있습니다 (jpg, png, gif).");
            }

            byte[] imageData = file.getBytes();
            oldItemService.registerItem(username, startingPrice, locate, imageData, sellerPhone, buyerPhone);

            redirectAttributes.addFlashAttribute("message", "아이템이 성공적으로 등록되었습니다.");
            return new ModelAndView("redirect:/registItem");

        } catch (IOException e) {
            logger.error("이미지 업로드 실패", e);
            return buildErrorModelAndView("이미지 업로드 실패: " + e.getMessage());
        }
    }

    @GetMapping("/my-items")
    @ResponseBody
    public List<oldItem> getItems(@RequestParam String username, @RequestParam int limit) {
        if (limit > 0) {
            return oldItemService.getRecentItems(limit);
        } else {
            return oldItemService.getItemsByUsername(username);
        }
    }

    @GetMapping("/myItem")
    public ModelAndView showMyItemPage(@RequestParam(required = false) String message,
                                       @RequestParam(required = false) String error,
                                       @RequestParam(defaultValue = "all") String filter) {
        String username = (String) session.getAttribute("username");

        if (!isValidUsername(username)) {
            return new ModelAndView("redirect:/login");
        }

        List<oldItem> items = filter.equals("user")
                ? oldItemService.getItemsByUsername(username)
                : oldItemService.getAllItems();

        ModelAndView mv = new ModelAndView("registItem");
        mv.addObject("username", username);
        mv.addObject("message", message);
        mv.addObject("error", error);
        mv.addObject("itemList", items);
        mv.addObject("buyerPhone", "");

        return mv;
    }

    private boolean isValidUsername(String username) {
        return username != null && !username.trim().isEmpty();
    }

    private boolean isImageContentType(String contentType) {
        return Objects.nonNull(contentType) &&
                (contentType.equalsIgnoreCase("image/jpeg") ||
                        contentType.equalsIgnoreCase("image/png") ||
                        contentType.equalsIgnoreCase("image/gif"));
    }

    private ModelAndView buildErrorModelAndView(String errorMessage) {
        ModelAndView mv = new ModelAndView("registItem");
        mv.addObject("error", errorMessage);
        mv.addObject("buyerPhone", "");
        return mv;
    }

}