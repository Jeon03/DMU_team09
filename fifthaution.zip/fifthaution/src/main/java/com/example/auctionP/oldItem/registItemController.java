package com.example.auctionP.oldItem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@Controller
public class registItemController {

    @Autowired
    private oldItemService oldItemService;

    @Autowired
    private HttpSession session;

    @GetMapping("/registItem")
    public ModelAndView showRegistItemPage() {
        String username = (String) session.getAttribute("username");

        ModelAndView modelAndView = new ModelAndView("registItem");
        modelAndView.addObject("username", username);

        return modelAndView;
    }

    // POST: 아이템 등록 처리
    @PostMapping("/createItem")
    public ModelAndView registerItem(@RequestParam String startingPrice,
                                     @RequestParam String locate,
                                     @RequestParam("itemPicture") MultipartFile file,
                                     @RequestParam String sellerPhone,
                                     @RequestParam String buyerPhone,
                                     RedirectAttributes redirectAttributes) {

        String username = (String) session.getAttribute("username");
        if (username == null) {
            return new ModelAndView("registItem", "error", "로그인이 필요합니다.");
        }

        try {
            byte[] itemPicture = file.isEmpty() ? null : file.getBytes();
            oldItemService.registerItem(username, startingPrice, locate, itemPicture, sellerPhone, buyerPhone);
            redirectAttributes.addFlashAttribute("message", "아이템이 성공적으로 등록되었습니다.");
            return new ModelAndView("redirect:/registItem");

        } catch (IOException e) {
            return new ModelAndView("registItem", "error", "파일 업로드 실패: " + e.getMessage());
        } catch (RuntimeException e) {
            return new ModelAndView("registItem", "error", e.getMessage());
        }
    }
}
