var stompClient = null;

function setConnected(connected) {
    $("#conversation").show();
    if (connected) {
        $("#conversation").show();
    } else {
        $("#conversation").hide();
    }
}

function connect() {
    var socket = new SockJS('/chat');  // WebSocket 연결
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        setConnected(true);
        console.log('Connected: ' + frame);
        var chatRoomId = $("#chatRoomId").val();
        stompClient.subscribe('/topic/chatRoom/' + chatRoomId, function (messageOutput) {
            showMessage(JSON.parse(messageOutput.body));
        });
    });
}

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}

function sendMessage() {
    var message = {
        sender: $("#sender").val(),
        content: $("#message").val(),
        chatRoomId: $("#chatRoomId").val()
    };
    stompClient.send("/app/sendMessage", {}, JSON.stringify(message));
    $("#message").val("");  // 메시지 전송 후 입력 필드 비우기
}

function showMessage(message) {
    $("#chat-room").append("<tr><td>" + message.sender + ": " + message.content + "</td></tr>");
}

$(function () {
    $("#chatForm").on('submit', function (e) {
        e.preventDefault();
        sendMessage();
    });
});
