package com.dream.ShareStory.oldItem;

public class ChargeRequest {
    private int amount;      // 충전할 금액
    private String password; // 사용자 비밀번호
    private Long id;   // 사용자 ID (세션에서 확인할 수 있도록)

    // Getters and Setters
    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
