package com.dream.ShareStory.oldItem;


import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
@Service
public class oldItemService {

    @Autowired
    private oldItemRepository oldItemRepository;

    @Autowired
    private MemberRepository memberRepository; // MemberRepository 주입

    public List<oldItem> searchItems(String type, String keyword) {
        switch (type) {
            case "title":
                return oldItemRepository.findByItemNameContaining(keyword); // itemName 검색
            case "detail":
                return oldItemRepository.findByItemDetailContaining(keyword); // itemDetail 검색
            case "memberName":
                // member.name을 통해 id를 찾고, 그 id를 기준으로 oldItem을 검색
                MemberEntity member = memberRepository.findByName(keyword); // 인스턴스를 통해 findByName 호출
                if (member != null) {
                    return oldItemRepository.findByMember_Id(member.getId()); // memberId를 기준으로 oldItem 조회
                }
                return Collections.emptyList(); // 멤버를 찾지 못한 경우 빈 리스트 반환
            default:
                return Collections.emptyList(); // 잘못된 검색 타입
        }
    }

    public oldItem save(oldItem item) {
        return oldItemRepository.save(item);
    }

    public List<oldItem> getRecentItems(int limit) {
        Pageable pageable = PageRequest.of(0, limit, Sort.by("itemId").descending());
        return oldItemRepository.findAllByOrderByItemIdDesc(pageable);
    }

    public Optional<oldItem> getItemById(Long id) {
        return oldItemRepository.findById(id);
    }

    public List<oldItem> getAllItems() {
        return oldItemRepository.findAll();
    }

    @Transactional(readOnly = true)
    public oldItem getItemDetail(Long id) {
        return oldItemRepository.findById(id).orElseThrow();
    }

    public void deleteItemById(Long id) {
        oldItem item = oldItemRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 상품입니다: id = " + id));
        oldItemRepository.delete(item); // 안전하게 삭제
    }

    public List<oldItem> findItemsByMemberId(Long memberId) {
        return oldItemRepository.findAllByMember_IdOrderByItemIdDesc(memberId);
    }
    public List<oldItem> getItemsForUser(Long memberId) {
        return oldItemRepository.findAllByMember_IdOrderByItemIdDesc(memberId);
    }

}
