package com.dream.ShareStory.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "message")
public class MessageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 쪽지 ID

    @ManyToOne
    @JoinColumn(name = "sender_id", nullable = false)
    private MemberEntity sender; // 보낸 사람

    @ManyToOne
    @JoinColumn(name = "receiver_id", nullable = false)
    private MemberEntity receiver; // 받는 사람

    @Column(nullable = false)
    private String title; // 쪽지 제목

    @Column(nullable = false, length = 1000)
    private String content; // 쪽지 내용

    @Column(nullable = false)
    private LocalDateTime sentAt = LocalDateTime.now(); // 보낸 시간


    @Column(nullable = true) // itemId는 필수는 아닌 것으로 설정
    private Long itemId; // 아이템 ID 추가
}
