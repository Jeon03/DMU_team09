package com.dream.ShareStory.config;

import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalSessionAttributes {

    @ModelAttribute
    public void addSessionAttributes(Model model, HttpSession session) {
        // 엔티티 PK에 맞춘 세션 키
        Long memberId = (Long) session.getAttribute("id");
        String name   = (String) session.getAttribute("name");
        if (memberId != null) {
            model.addAttribute("sessionMemberId", memberId);
            model.addAttribute("sessionName",     name);
        }
    }
}