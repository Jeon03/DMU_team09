package com.dream.ShareStory.chat;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ChatController {

    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public ChatController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/sendMessage")
    public void sendMessage(ChatMessage message) {
        // 메시지 객체에 roomId가 포함되어 있어야 함
        String destination = "/topic/chatRoom/" + message.getChatRoomId();
        messagingTemplate.convertAndSend(destination, message);
    }
    @GetMapping("/chatRoom/{chatRoomId}")
    public String chatRoom(@PathVariable String chatRoomId, Model model, HttpSession session) {
        Long sessionMemberId = (Long) session.getAttribute("sessionMemberId");
        if (sessionMemberId == null) {
            return "redirect:/login";
        }

        model.addAttribute("chatRoomId", chatRoomId);
        model.addAttribute("sessionMemberId", sessionMemberId);
        return "chat/chatRoom";  // 여기!
    }
}
