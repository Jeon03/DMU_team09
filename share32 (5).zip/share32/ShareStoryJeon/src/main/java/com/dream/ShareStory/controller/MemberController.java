package com.dream.ShareStory.controller;

import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.service.MemberService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.json.JsonWriter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class MemberController {
    // 생성자 주입
    private final MemberService memberService;

    // 회원가입 페이지 출력 요청
    @GetMapping("/member/signup")
    public String signupForm(){
        return "signup";
    }

    @PostMapping("/member/signup")
    public String signup(@ModelAttribute MemberDTO memberDTO){
        memberService.signup(memberDTO);
        return "login";
    }

    @GetMapping("/member/login")
    public String loginForm(){
        return "login";
    }

    @PostMapping("/member/login")
    public String login(@ModelAttribute MemberDTO memberDTO, HttpSession session,Model model){
        MemberDTO loginResult = memberService.login(memberDTO);
        if(loginResult != null){
            session.setAttribute("id", loginResult.getId() != null ? loginResult.getId() : 0L);
            session.setAttribute("email", loginResult.getEmail() != null ? loginResult.getEmail() : "");
            session.setAttribute("name", loginResult.getName() != null ? loginResult.getName() : "");
            session.setAttribute("age", loginResult.getAge() != null ? loginResult.getAge() : 0);
            session.setAttribute("points", loginResult.getPoints() != null ? loginResult.getPoints() : 0);
            session.setAttribute("city", loginResult.getCity() != null ? loginResult.getCity() : "");
            session.setAttribute("password", loginResult.getPassword() != null ? loginResult.getPassword() : "");

            session.setAttribute("sessionMemberId", loginResult.getId());  // 추가된 부분
            boolean isAdmin =
                    "zxc".equals(loginResult.getEmail()) &&
                            "zxc".equals(loginResult.getPassword());
// 로그 추가하여 isAdmin 값 확인
            System.out.println("isAdmin 계산 결과: " + isAdmin);  // 로그인 시 isAdmin 값 확인
            session.setAttribute("isAdmin", isAdmin);
            model.addAttribute("isAdmin", isAdmin);

            model.addAttribute("member", loginResult);

            // ★ 페이지 분기
            if (isAdmin) {
                return "adminMain"; // 관리자 메인
            } else {
                return "main"; // 일반 메인
            }
        } else {
            return "login"; // 로그인 실패
        }
    }

    @GetMapping("/member/")
    public String findAll(Model model){
        List<MemberDTO> memberDTOList = memberService.findAll();
        model.addAttribute("memberList", memberDTOList);
        return "list";
    }

    @GetMapping("/member/detail/{id}") // {id}를 받아주는 어노테이션 pathvariable
    public String findById(@PathVariable Long id, Model model){
        MemberDTO memberDTO = memberService.findbyId(id);
        model.addAttribute("member", memberDTO);
        return "main";
    }

    // 수정된 updateForm 메서드 (id를 사용)
    @GetMapping("/member/update/{id}")
    public String updateForm(@PathVariable Long id, HttpSession session, Model model) {
        // memberService.updateForm(id)를 호출하여 id를 이용한 업데이트 폼을 가져옴
        MemberDTO memberDTO = memberService.updateForm(id);  // id를 이용하여 업데이트 폼을 가져옴
        model.addAttribute("id", memberDTO.getId());
        model.addAttribute("email", memberDTO.getEmail());
        model.addAttribute("password", memberDTO.getPassword());
        model.addAttribute("name", memberDTO.getName());
        model.addAttribute("age", memberDTO.getAge());
        model.addAttribute("city", memberDTO.getCity());
        return "updateForm";  // updateForm.html을 반환
    }

    @PostMapping("/member/update")
    public String update(@ModelAttribute MemberDTO memberDTO) {
        // 비밀번호, 나이, 도시만 업데이트하도록 처리
        MemberDTO existingMember = memberService.findbyId(memberDTO.getId());

        // 변경된 값만 업데이트
        if (memberDTO.getPassword() != null && !memberDTO.getPassword().isEmpty()) {
            existingMember.setPassword(memberDTO.getPassword());
        }
        if (memberDTO.getAge() != 0) {
            existingMember.setAge(memberDTO.getAge());
        }
        if (memberDTO.getCity() != null && !memberDTO.getCity().isEmpty()) {
            existingMember.setCity(memberDTO.getCity());
        }

        // 변경된 정보 저장
        memberService.update(existingMember);

        // 업데이트 후 해당 회원의 상세 페이지로 리다이렉트
        return "main";
    }

    @GetMapping("/member/delete/{id}")
    public String deleteById(@PathVariable Long id){
        memberService.deleteById(id);
        return "redirect:/member/";
    }

    @GetMapping("/member/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "index";
    }
    @GetMapping("/main")
    public String mainPage(HttpSession session, Model model) {
        // 세션에서 사용자 정보 꺼내기
        Long id = (Long) session.getAttribute("id");
        String email = (String) session.getAttribute("email");
        String name = (String) session.getAttribute("name");
        Integer age = (Integer) session.getAttribute("age");
        String city = (String) session.getAttribute("city");
        Integer points = (Integer) session.getAttribute("points");
        String password = (String) session.getAttribute("password");

        if (id != null && name != null) {
            // 세션값으로 MemberDTO 객체 구성
            MemberDTO memberDTO = new MemberDTO();
            memberDTO.setId(id);
            memberDTO.setEmail(email);
            memberDTO.setName(name);
            memberDTO.setAge(age);
            memberDTO.setCity(city);
            memberDTO.setPoints(points);
            memberDTO.setPassword(password);

            // 로그인할 때처럼 모델에 member 추가
            model.addAttribute("member", memberDTO);

            return "main";
        } else {
            return "redirect:/member/login"; // 로그인 안 돼 있으면 다시 로그인
        }
    }

    @GetMapping("/list")
    @ResponseBody
    public List<MemberDTO> getMemberList() {
        return memberService.findAllDTO();  // DTO 리스트 반환
    }
    @GetMapping("/admin/member/update/{id}")
    public String adminUpdateForm(@PathVariable Long id, HttpSession session, Model model) {

        System.out.println("adminUpdateForm 호출됨, 받은 id: " + id);
        // 관리자 세션 확인

        MemberDTO loggedInAdmin = (MemberDTO) session.getAttribute("loggedInMember");

        // 관리자가 아니면 로그인 페이지로 리다이렉트


        // 관리자가 아닌 경우 memberService로 해당 회원 정보 불러오기
        MemberDTO memberDTO = memberService.findbyId(id);  // findbyId()를 호출하여 해당 회원 정보 가져오기

        // 회원 정보가 없으면 에러 페이지로 리다이렉트
        if (memberDTO == null) {
            return "errorPage";  // 오류 페이지로 리다이렉트
        }

        // 모델에 정보 전달
        model.addAttribute("id", memberDTO.getId());
        model.addAttribute("email", memberDTO.getEmail());
        model.addAttribute("password", memberDTO.getPassword());
        model.addAttribute("name", memberDTO.getName());
        model.addAttribute("age", memberDTO.getAge());
        model.addAttribute("city", memberDTO.getCity());

        return "updateForm2";  // 관리자용 회원 업데이트 폼 반환
    }


}
