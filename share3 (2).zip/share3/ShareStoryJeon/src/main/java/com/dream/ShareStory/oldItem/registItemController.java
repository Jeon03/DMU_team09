package com.dream.ShareStory.oldItem;

import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.repository.MemberRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Controller
public class registItemController {

    private final oldItemService oldItemService;
    private final HttpSession session;
    private final MemberRepository memberRepository;

    @Autowired
    public registItemController(oldItemService oldItemService, HttpSession session, MemberRepository memberRepository) {
        this.oldItemService = oldItemService;
        this.session = session;
        this.memberRepository = memberRepository;
    }

    @GetMapping("/registItem")
    public ModelAndView showRegistItemPage(@RequestParam(required = false) String message,
                                           @RequestParam(required = false) String error) {
        Long id = (Long) session.getAttribute("id");

        if (id == null) {
            return new ModelAndView("redirect:/member/login");
        }

        List<oldItem> recentItems = oldItemService.getRecentItems(5);
        ModelAndView modelAndView = new ModelAndView("registItem");
        modelAndView.addObject("username", session.getAttribute("username"));
        modelAndView.addObject("message", message);
        modelAndView.addObject("error", error);
        modelAndView.addObject("recentItems", recentItems);

        return modelAndView;
    }

    @PostMapping("/createItem")
    public String registerOldItem(@RequestParam String itemName,
                                  @RequestParam String itemDetail,
                                  @RequestParam String itemCategory,
                                  @RequestParam BigDecimal itemPrice,
                                  @RequestParam Integer itemQuantity,
                                  @RequestParam MultipartFile itemPicture,
                                  @RequestParam String itemCondition,
                                  @RequestParam String deliveryTransaction,
                                  RedirectAttributes redirectAttributes) {
        try {
            Long id = (Long) session.getAttribute("id");

            if (id == null) {
                redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
                return "redirect:/registItem";
            }

            if (itemPicture.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "유효한 이미지가 필요합니다.");
                return "redirect:/registItem";
            }

            oldItem newItem = new oldItem();
            Optional<MemberEntity> memberOpt = memberRepository.findById(id);

            if (memberOpt.isPresent()) {
                newItem.setMember(memberOpt.get());
            } else {
                throw new RuntimeException("해당 id의 회원을 찾을 수 없습니다: " + id);
            }

            newItem.setItemName(itemName);
            newItem.setItemDetail(itemDetail);
            newItem.setItemCategory(itemCategory);
            newItem.setItemPrice(itemPrice);
            newItem.setItemQuantity(itemQuantity);
            newItem.setItemPicture(itemPicture.getBytes());
            newItem.setItemCondition(itemCondition);
            newItem.setDeliveryTransaction(deliveryTransaction);

            oldItemService.save(newItem);

            redirectAttributes.addFlashAttribute("message", "상품이 등록되었습니다!");
            return "redirect:/registItem";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "상품 등록 중 오류가 발생했습니다.");
            return "redirect:/registItem";
        }
    }

    @GetMapping("/my-items")
    @ResponseBody
    public oldItem getItem(@RequestParam Long id) {
        return oldItemService.getItemById(id).orElse(null);
    }

    @GetMapping("/myItem")
    public ModelAndView showMyItemPage(@RequestParam(required = false) String message,
                                       @RequestParam(required = false) String error) {
        Long id = (Long) session.getAttribute("id");

        if (id == null) {
            return new ModelAndView("redirect:/login");
        }

        List<oldItem> items = oldItemService.getAllItems();
        ModelAndView mv = new ModelAndView("myItem");
        mv.addObject("message", message);
        mv.addObject("error", error);
        mv.addObject("itemList", items);

        return mv;
    }
}
