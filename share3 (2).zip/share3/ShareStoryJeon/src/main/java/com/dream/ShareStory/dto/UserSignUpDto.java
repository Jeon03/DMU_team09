package com.dream.ShareStory.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class UserSignUpDto {
    private Long id;
    private String email;
    private String password;
    private String name;
    private int age;
    private String city;
    private int points;//0402추가
}
