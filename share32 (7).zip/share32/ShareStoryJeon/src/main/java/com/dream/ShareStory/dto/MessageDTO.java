package com.dream.ShareStory.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MessageDTO {
    private Long id;              // 메시지 ID
    private Long senderId;        // 보낸 사람 ID
    private String senderName;    // 보낸 사람 이름
    private Long receiverId;      // 받는 사람 ID
    private String title;         // 제목
    private String content;       // 내용
    private Long itemId;          // 상품 ID (필요시)
       // 읽음 여부
    private LocalDateTime sentAt; // 보낸 시간
}
