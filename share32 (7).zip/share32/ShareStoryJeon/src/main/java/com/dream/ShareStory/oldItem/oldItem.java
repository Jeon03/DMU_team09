package com.dream.ShareStory.oldItem;

import jakarta.persistence.*;
import lombok.*;
import com.dream.ShareStory.entity.MemberEntity;
import java.math.BigDecimal;
import java.util.Base64;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class oldItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "member_id")
    private MemberEntity member;

   @Lob
    @ToString.Exclude
    private byte[] itemPicture;
   // private String  imageUrl;//

    private String itemName;
    private String itemDetail;
    private String itemCategory;
    private BigDecimal itemPrice;
    private Integer itemQuantity;

    private String itemCondition;
    private String deliveryTransaction;
    private String tradeLocation;
    private Double latitude;
    private Double longitude;

    // 🔽 추가된 부분
    @Transient
    public String getBase64Image() {
        if (itemPicture != null) {
            return Base64.getEncoder().encodeToString(itemPicture);
        }
        return null;
    }


}
