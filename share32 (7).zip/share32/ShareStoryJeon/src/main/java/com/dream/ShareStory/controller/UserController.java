package com.dream.ShareStory.controller;

import com.dream.ShareStory.dto.UserSignUpDto;
import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.oldItem.ChargeRequest;
import com.dream.ShareStory.repository.MemberRepository;
import com.dream.ShareStory.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final MemberRepository memberRepository; // ✅ 여기 주입!

    @PostMapping("/sign-up")
    public String signUp(@RequestBody UserSignUpDto userSignUpDto) throws Exception {
        userService.signUp(userSignUpDto);
        return "회원가입 성공";
    }

    @GetMapping("/jwt-test")
    public String jwtTest() {
        return "jwtTest 요청 성공";
    }

    @PostMapping("/user/chargePoints")
    public ResponseEntity<String> chargePoint(@RequestBody ChargeRequest chargeRequest, HttpSession session) {
        // 세션에서 저장된 사용자 이메일과 비밀번호 가져오기
        String sessionEmail = (String) session.getAttribute("email"); // ✅ 'username' → 'email'


        // 로그인 여부 확인
        if (sessionEmail == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("로그인이 필요합니다.");
        }

        // 비밀번호 확인


        // 이메일로 사용자 조회
        Optional<MemberEntity> optionalMember = memberRepository.findByEmail(sessionEmail);
        if (optionalMember.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("사용자를 찾을 수 없습니다.");
        }

        MemberEntity user = optionalMember.get();

        // 포인트 충전
        int newPoint = user.getPoints() + chargeRequest.getAmount();
        user.setPoints(newPoint);
        memberRepository.save(user); // 저장

        // 세션에 최신 정보 갱신
        session.setAttribute("user", user);

        return ResponseEntity.ok("포인트 충전 완료! 현재 포인트: " + newPoint);
    }

}
