import React from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Banner from './components/Banner';
import ProductList from './components/ProductList';
import RecentProductsSidebar from './components/RecentProductsSidebar';
import Footer from './components/Footer';
import './App.css';

function App() {
    return (
        <div className="App">
            <Header />
            <main className="main-content">
                <div className="content-wrapper">
                    <Navigation />
                    <Banner />
                    <ProductList />
                </div>
                <RecentProductsSidebar />
            </main>
            <Footer />
        </div>
    );
}

export default App;
