import React from 'react';

function Navigation() {
    return (
        <nav className="nav">
            <button className="menu-icon">☰</button>
            <a href="#">중고거래</a>
            <a href="#">물품경매</a>
            <a href="#">커뮤니티</a>
        </nav>
    );
}

export default Navigation;
