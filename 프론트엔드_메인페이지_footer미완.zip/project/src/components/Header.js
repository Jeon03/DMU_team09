import React from 'react';
import logo from '../images/logo.png';
import searchIcon from '../images/search.svg';
import LocationSelector from './LocationSelector';

function Header() {
    return (
        <header className="header container">
            <div className="logo">
                <img src={logo} alt="Logo" />
            </div>
            <div className="search-area">
                <LocationSelector />
                <div className="header_search-box">
                    <input type="text" placeholder="어떤 상품을 찾으시나요?" className="search-input" />
                    <img src={searchIcon} className="search-icon" alt="search" />
                </div>
            </div>
            <div className="menu-links">
                <a href="#">로그인 / 회원가입</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">판매하기</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">채팅하기</a>
            </div>
        </header>
    );
}

export default Header;
