import React from 'react';

function Footer() {
    return (
        <footer className="footer">
            {/* 푸터 내용 */}
        </footer>
    );
}

export default Footer;
