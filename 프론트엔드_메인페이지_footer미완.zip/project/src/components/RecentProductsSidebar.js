import React from 'react';
import testImage from '../images/testImage.png';

function RecentProductsSidebar() {
    return (
        <aside className="recent-products">
            <h4>최근 본 상품</h4>
            <div className="recent-item"><img src={testImage} alt="recent1" /></div>
            <div className="recent-item"><img src={testImage} alt="recent2" /></div>
            <div className="recent-item"><img src={testImage} alt="recent3" /></div>
        </aside>
    );
}

export default RecentProductsSidebar;
