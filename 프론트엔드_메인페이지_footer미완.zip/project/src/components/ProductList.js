import React from 'react';
import testImage from '../images/testImage.png'

function ProductList() {
    return (
        <section className="product-list">
            <h3>방금 등록된 상품</h3>
            <div className="products">
                {Array(8).fill().map((_, idx) => (
                    <div key={idx} className="product-card">
                        <img src={testImage} alt={`상품 ${idx + 1}`} />
                        <div className="product-info">
                            <p>상품명 {idx + 1}</p>
                            <p>10,000원</p>
                            <p className="location">구로구</p>
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}

export default ProductList;
