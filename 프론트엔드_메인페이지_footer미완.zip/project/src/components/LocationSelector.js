import React, { useState } from 'react';
import './css/LocationSelector.css'; // 스타일은 따로 관리

// 이미지 import 추가
import caretDownIcon from '../images/caret-down-fill.svg';
import closeIcon from '../images/x.svg';
import searchIcon from '../images/search.svg';
import crosshairIcon from '../images/crosshair.svg';

function LocationSelector() {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedLocation, setSelectedLocation] = useState('구로구');
    const [selectedValue, setSelectedValue] = useState('apple');

    const locations = [
        { value: 'loc_1', label: '인천광역시, 연수구, 송도동' },
        { value: 'loc_2', label: '서울특별시, 강남구, 역삼동' },
        { value: 'loc_3', label: '경기도, 화성시, 봉담읍' },
    ];

    const handleSelect = (location) => {
        setSelectedLocation(location.label);
        setSelectedValue(location.value);
        setIsOpen(false);
    };

    return (
        <>
            {/* 선택 버튼 */}
            <button className="select-button" onClick={() => setIsOpen(true)}>
                <img src={caretDownIcon} alt="arrow" />
                {selectedLocation}
            </button>
            <input type="hidden" name="location" value={selectedValue} />

            {/* 오버레이 */}
            {isOpen && <div className="overlay" onClick={() => setIsOpen(false)}></div>}

            {/* 팝업 */}
            {isOpen && (
                <div className="popup">
                    <div className="popup_nav">
                        지역 변경
                        <button className="close-button" onClick={() => setIsOpen(false)}>
                            <img src={closeIcon} alt="close" />
                        </button>
                    </div>
                    <hr />
                    <div className="searchMenu">
                        <div className="search-box">
                            <input
                                type="text"
                                placeholder="지역이나 동네로 검색하기"
                                className="search-input"
                            />
                            <img src={searchIcon} className="search-icon" alt="search" />
                        </div>
                    </div>

                    <div className="search-button">
                        <button className="myPosition-button">
                            <img src={crosshairIcon} alt="position" /> 현재 내 위치 사용하기
                        </button>
                    </div>

                    {/* 기본 옵션 목록 */}
                    <div className="default-options">
                        {locations.map((loc) => (
                            <div
                                key={loc.value}
                                className="option"
                                onClick={() => handleSelect(loc)}
                            >
                                {loc.label}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </>
    );
}

export default LocationSelector;
