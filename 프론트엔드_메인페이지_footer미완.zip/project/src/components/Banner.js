import React from 'react';
import bannerImage from '../images/bannerImage.png';

function Banner() {
    return (
        <section className="banner">
            <img src={bannerImage} alt="Banner" />
        </section>
    );
}

export default Banner;
