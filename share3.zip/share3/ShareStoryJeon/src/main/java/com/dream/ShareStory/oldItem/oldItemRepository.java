package com.dream.ShareStory.oldItem;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface oldItemRepository extends JpaRepository<oldItem, Long> {

    // 특정 사용자 ID로 등록한 아이템 페이징 처리 (최신순)
    List<oldItem> findAllByMember_IdOrderByItemIdDesc(Long id);

    // 전체 최신 아이템 페이징 처리
    List<oldItem> findAllByOrderByItemIdDesc(Pageable pageable);
}
