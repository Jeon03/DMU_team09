package com.dream.ShareStory.dto;


import com.dream.ShareStory.entity.MemberEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor  //기본생성자 자동생성
@ToString
public class MemberDTO {
    private Long id;
    private String email;
    private String password;
    private String name;
    private int age;
    private String city;
    private int points;

    public MemberDTO(Long id, String name, String email, Integer age, String city, String password, Integer points) {



    this.id = id;
    this.name = name;
    this.email = email;
    this.age = age;
    this.city = city;
    this.password = password;
    this.points = points;
        }

    public static MemberDTO toMemberDTO(MemberEntity memberEntity){
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setId(memberEntity.getId());
        memberDTO.setEmail(memberEntity.getEmail());
        memberDTO.setPassword(memberEntity.getPassword());
        memberDTO.setName(memberEntity.getName());
        memberDTO.setAge(memberEntity.getAge());
        memberDTO.setCity(memberEntity.getCity());
        memberEntity.setPoints(memberDTO.getPoints());//0402추가
        return memberDTO;
    }
}
