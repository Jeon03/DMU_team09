


document.getElementById("chargePointsBtn").addEventListener("click", function() {
    document.getElementById("pointPopup").style.display = "block";
});

document.getElementById("closePopup").addEventListener("click", function() {
    document.getElementById("pointPopup").style.display = "none";
});

function updatePoints() {
    const amount = document.getElementById("amount").value;
    const pointsField = document.getElementById("point");

    if (/^\d+$/.test(amount)) {
        pointsField.value = amount;
    } else {
        pointsField.value = '';
    }
}

document.getElementById("chargeBtn").addEventListener("click", function() {
    const amount = document.getElementById("amount").value;
    const password = document.getElementById("password").value;

    if (!amount || !password) {
        alert('금액과 비밀번호를 입력해주세요.');
        return;
    }

    if (!/^\d+$/.test(amount)) {
        alert('금액은 숫자만 입력해야 합니다.');
        return;
    }

    fetch('/user/chargePoints', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'  // JSON 형식으로 변경
        },
        body: JSON.stringify({
            amount: parseInt(amount, 10),  // 문자열을 숫자로 변환
            password: password
        })
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
        })
        .catch(error => {
            alert('서버와의 통신에 실패했습니다.');
        });

});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("itemPicture").addEventListener("change", function (event) {
        const preview = document.getElementById("previewImage");
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.visibility = "visible"; // 보이게만
            };
            reader.readAsDataURL(file);
        } else {
            preview.style.visibility = "hidden"; // 다시 감춤
            preview.src = ""; // 이미지 제거
        }
    });
});

