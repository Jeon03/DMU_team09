package OAuth;

import OAuth.practice.oauth.dto.UserProfile;


import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;

public enum OAuthAttributes {

    GOOGLE("google", (attribute) -> {
        UserProfile userProfile = new UserProfile();
        userProfile.setUsername((String)attribute.get("name"));
        userProfile.setEmail((String)attribute.get("email"));

        return userProfile;
    }),
    NAVER("naver", (attribute) -> {
        UserProfile userProfile = new UserProfile();

        Map<String, String> responseValue = (Map)attribute.get("response");

        userProfile.setUsername(responseValue.get("name"));
        userProfile.setEmail(responseValue.get("email"));
        return userProfile;
    }),
    KAKAO("kakao", (attribute) -> {
        System.out.println(attribute.get("name")+"-----------------------------------------------");
        System.out.println(attribute.get("name")+"-----------------------------------------------");
        System.out.println(attribute.get("name")+"-----------------------------------------------");
        System.out.println(attribute.get("name")+"-----------------------------------------------");
        System.out.println(attribute.get("name")+"-----------------------------------------------");
        Map<String, Object> account = (Map)attribute.get("kakao_account");
        Map<String, String> profile = (Map)account.get("profile");

        UserProfile userProfile = new UserProfile();
        userProfile.setUsername(profile.get("nickname"));
        userProfile.setEmail((String)account.get("email"));

        return userProfile;
    });

    private final String registrationId;
    private final Function<Map<String, Object>, UserProfile> of;

    OAuthAttributes(String registrationId, Function<Map<String,Object>,UserProfile> of) {
        this.registrationId = registrationId;
        this.of = of;
    }
    public static UserProfile extract(String registrationId, Map<String, Object> attributes) {
        System.out.println("1233333331233333333333333333333333333333333333333333333333333333333333");
        return Arrays.stream(values())
                .filter(value -> registrationId.equals(value.registrationId))
                .findFirst()
                .orElseThrow(IllegalArgumentException::new)
                .of.apply(attributes);
    }

}
