package com.dream.ShareStory.entity;

import com.dream.ShareStory.dto.MemberDTO;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name="member_list")
public class MemberEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto_increment
    private Long id;

    @Column(unique = true)
    private String email;

    @Column
    private String password;

    @Column(nullable = true)
    private String name="";

    @Column(nullable = true)
    private Integer age=0;

    @Column(nullable = true)
    private String city="도시";

    @Column(nullable = true)
    private Integer points = 0;

    @PrePersist
    public void prePersist() {
        // points가 null이면 0으로 설정
        if (this.points == null) {
            this.points = 0;
        }

        // name이 null이면 빈 문자열로 설정
        if (this.name == null) {
            this.name = "이름";
        }

        // age가 null이면 0으로 설정
        if (this.age == null) {
            this.age = 0;
        }

        // city가 null이면 "도시"로 설정
        if (this.city == null) {
            this.city = "도시";
        }
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public static MemberEntity toMemberEntity(MemberDTO memberDTO) {
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setEmail(memberDTO.getEmail());
        memberEntity.setPassword(memberDTO.getPassword());
        memberEntity.setName(memberDTO.getName());
        memberEntity.setAge(memberDTO.getAge());
        memberEntity.setCity(memberDTO.getCity());
        memberEntity.setPoints(memberDTO.getPoints());
        return memberEntity;
    }

    public static MemberEntity toUpdateMemberEntity(MemberDTO memberDTO) {
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setId(memberDTO.getId());
        memberEntity.setEmail(memberDTO.getEmail());
        memberEntity.setPassword(memberDTO.getPassword());
        memberEntity.setName(memberDTO.getName());
        memberEntity.setAge(memberDTO.getAge());
        memberEntity.setCity(memberDTO.getCity());
        memberEntity.setPoints(memberDTO.getPoints());
        return memberEntity;
    }
}
