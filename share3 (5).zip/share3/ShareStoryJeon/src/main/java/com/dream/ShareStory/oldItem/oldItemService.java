package com.dream.ShareStory.oldItem;


import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class oldItemService {

    private final oldItemRepository oldItemRepository;
    private final MemberRepository memberRepository;

    @Autowired
    public oldItemService(oldItemRepository oldItemRepository, MemberRepository memberRepository) {
        this.oldItemRepository = oldItemRepository;
        this.memberRepository = memberRepository;
    }

    public oldItem registerItem(Long id, oldItem newItem) {
        MemberEntity member = memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("해당 id의 회원을 찾을 수 없습니다: " + id));

        newItem.setMember(member);
        return oldItemRepository.save(newItem);
    }

    public oldItem save(oldItem item) {
        return oldItemRepository.save(item);
    }

    public List<oldItem> getRecentItems(int limit) {
        Pageable pageable = PageRequest.of(0, limit, Sort.by("itemId").descending());
        return oldItemRepository.findAllByOrderByItemIdDesc(pageable);
    }

    public Optional<oldItem> getItemById(Long id) {
        return oldItemRepository.findById(id);
    }

    public List<oldItem> getAllItems() {
        return oldItemRepository.findAll();
    }

    @Transactional(readOnly = true)
    public oldItem getItemDetail(Long id) {
        return oldItemRepository.findById(id).orElseThrow();
    }



    @Autowired
    private oldItemRepository itemRepository;

    public void deleteItemById(Long id) {
        oldItem item = itemRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 상품입니다: id = " + id));

        itemRepository.delete(item); // 안전하게 삭제
    }

   /* @Service
    public class S3Uploader {
        private final AmazonS3 amazonS3;

        @Value("${cloud.aws.s3.bucket}")
        private String bucket;

        public S3Uploader(AmazonS3 amazonS3) {
            this.amazonS3 = amazonS3;
        }

        public String upload(MultipartFile file) throws IOException {
            String fileName = UUID.randomUUID() + "-" + file.getOriginalFilename();
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(file.getSize());
            amazonS3.putObject(bucket, fileName, file.getInputStream(), metadata);
            return amazonS3.getUrl(bucket, fileName).toString(); // URL 리턴
        }
    }
*/
   public List<oldItem> findItemsByMemberId(Long memberId) {
       return oldItemRepository.findAllByMember_IdOrderByItemIdDesc(memberId);
   }

}