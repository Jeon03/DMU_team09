package com.dream.ShareStory.repository;

import com.dream.ShareStory.entity.MessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MessageRepository extends JpaRepository<MessageEntity, Long> {

    // 특정 사용자가 받은 쪽지 목록
    List<MessageEntity> findByReceiverId(Long receiverId);

    // 특정 사용자가 보낸 쪽지 목록
    List<MessageEntity> findBySenderId(Long senderId);

    // 읽지 않은 메시지만 가져오기 (선택)
    List<MessageEntity> findByReceiverIdAndIsReadFalse(Long receiverId);

    List<MessageEntity> findByReceiver_Id(Long  receiverId);

}
