package com.dream.ShareStory.service;

import com.dream.ShareStory.dto.MessageDTO;
import com.dream.ShareStory.entity.MemberEntity;
import com.dream.ShareStory.entity.MessageEntity;
import com.dream.ShareStory.repository.MemberRepository;
import com.dream.ShareStory.repository.MessageRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MessageService {

    private final MemberRepository memberRepository;
    private final MessageRepository messageRepository;

    public MessageService(MemberRepository memberRepository, MessageRepository messageRepository) {
        this.memberRepository = memberRepository;
        this.messageRepository = messageRepository;
    }

    public void sendMessage(MessageDTO dto) {
        MemberEntity sender = memberRepository.findById(dto.getSenderId())
                .orElseThrow(() -> new IllegalArgumentException("보낸 사람 없음"));
        MemberEntity receiver = memberRepository.findById(dto.getReceiverId())
                .orElseThrow(() -> new IllegalArgumentException("받는 사람 없음"));

        MessageEntity message = new MessageEntity();
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setTitle(dto.getTitle());
        message.setContent(dto.getContent());
        message.setSentAt(LocalDateTime.now());

        messageRepository.save(message);
    }
    public MessageEntity getMessageById(Long id) {
        Optional<MessageEntity> message = messageRepository.findById(id);
        return message.orElse(null); // 없으면 null 리턴
    }
    public List<MessageEntity> getMessagesForUser(Long  memberId) {
        return messageRepository.findByReceiver_Id(memberId);
    }

}
