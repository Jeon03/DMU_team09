package com.dream.ShareStory.controller;

import com.dream.ShareStory.oldItem.oldItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.dream.ShareStory.oldItem.oldItemService;
import java.util.List;

@Controller
public class searchItemsController {
    @Autowired
    private oldItemService oldItemService;


    @GetMapping("/search")
    public String searchItems(@RequestParam("type") String type,
                              @RequestParam("keyword") String keyword,
                              Model model) {
        // 검색한 키워드와 타입을 기반으로 아이템 검색
        List<oldItem> result = oldItemService.searchItems(type, keyword);
        model.addAttribute("itemList", result);
        model.addAttribute("keyword", keyword); // 검색어도 결과 페이지에 보여줍니다.
        return "itemList"; // 결과를 보여줄 템플릿
    }
}