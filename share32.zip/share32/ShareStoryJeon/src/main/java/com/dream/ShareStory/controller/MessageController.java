package com.dream.ShareStory.controller;
import com.dream.ShareStory.dto.MemberDTO;
import com.dream.ShareStory.entity.MessageEntity;
import com.dream.ShareStory.dto.MessageDTO;
import com.dream.ShareStory.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/message")
public class MessageController {

    private final MessageService messageService;

    @PostMapping("/send")
    public ResponseEntity<String> sendMessage(@RequestBody MessageDTO messageDTO) {
        try {
            messageService.sendMessage(messageDTO);
            return ResponseEntity.ok("쪽지를 보냈습니다!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("쪽지 전송 실패: " + e.getMessage());
        }
    }




    @GetMapping("/detail/{id}")
    public String showMessageDetail(@PathVariable Long id, @SessionAttribute(name = "memberId", required = false) String memberId, Model model) {
        if (memberId == null) {
            return "redirect:/login"; // 로그인하지 않았다면 로그인 페이지로 리다이렉트
        }

        MessageEntity message = messageService.getMessageById(id);
        if (message == null || !message.getReceiver().getId().equals(memberId)) {
            return "redirect:/message/inbox"; // 본인의 쪽지가 아니면 쪽지함으로 리다이렉트
        }

        model.addAttribute("message", message);
        return "messageDetail"; // 쪽지 상세 페이지로 리턴
    }
    @GetMapping("/inbox")
    public String showInbox(@SessionAttribute(name = "id", required = false) Long  memberId, Model model) {
        MemberDTO memberDTO = (MemberDTO) model.getAttribute("member");
        if (memberId == null) {
            return "redirect:/login";
        }

        List<MessageEntity> message = messageService.getMessagesForUser(memberId);
        model.addAttribute("message", message);
        return "inbox";
    }


}
