package com.dream.ShareStory.oldItem;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface oldItemRepository extends JpaRepository<oldItem, Long> {

    // 특정 사용자 ID로 등록한 아이템 페이징 처리 (최신순)
    List<oldItem> findAllByMember_IdOrderByItemIdDesc(Long id);

    // 전체 최신 아이템 페이징 처리
    List<oldItem> findAllByOrderByItemIdDesc(Pageable pageable);

    List<oldItem> findByItemNameContainingOrItemDetailContaining(String name, String detail);

    // 판매자 (MemberEntity의 name)
    List<oldItem> findByMember_NameContaining(String name);

    List<oldItem> findByItemNameContaining(String itemName); // itemName 검색
    List<oldItem> findByItemDetailContaining(String itemDetail); // itemDetail 검색
    List<oldItem> findByMember_Id(Long memberId); // memberId 기준으로 검색
}





