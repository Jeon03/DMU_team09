package com.dream.ShareStory.dto;

import lombok.Data;

@Data
public class MessageDTO {
    private Long senderId;
    private Long receiverId;
    private String title;
    private String content;
    private Long itemId; // 추가
}