package com.demoproject.jeon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeonApplicationTests {

	@Test
	void contextLoads() {
	}

}
